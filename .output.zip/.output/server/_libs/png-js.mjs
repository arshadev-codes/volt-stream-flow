import fs from "fs";
import { inflate as inflate$1 } from "zlib";
const inflate = inflate$1;
let PNG$1 = class PNG {
  static decode(path, fn) {
    {
      return fs.readFile(path, function(err, file) {
        const png = new PNG(file);
        return png.decode((pixels) => fn(pixels));
      });
    }
  }
  static load(path) {
    {
      const file = fs.readFileSync(path);
      return new PNG(file);
    }
  }
  constructor(data) {
    let i;
    this.data = data;
    this.pos = 8;
    this.palette = [];
    this.imgData = [];
    this.transparency = {};
    this.text = {};
    while (true) {
      const chunkSize = this.readUInt32();
      let section = "";
      for (i = 0; i < 4; i++) {
        section += String.fromCharCode(this.data[this.pos++]);
      }
      switch (section) {
        case "IHDR":
          this.width = this.readUInt32();
          this.height = this.readUInt32();
          this.bits = this.data[this.pos++];
          this.colorType = this.data[this.pos++];
          this.compressionMethod = this.data[this.pos++];
          this.filterMethod = this.data[this.pos++];
          this.interlaceMethod = this.data[this.pos++];
          break;
        case "PLTE":
          this.palette = this.read(chunkSize);
          break;
        case "IDAT":
          for (i = 0; i < chunkSize; i++) {
            this.imgData.push(this.data[this.pos++]);
          }
          break;
        case "tRNS":
          this.transparency = {};
          switch (this.colorType) {
            case 3:
              this.transparency.indexed = this.read(chunkSize);
              var short = 255 - this.transparency.indexed.length;
              if (short > 0) {
                for (i = 0; i < short; i++) {
                  this.transparency.indexed.push(255);
                }
              }
              break;
            case 0:
              this.transparency.grayscale = this.read(chunkSize)[0];
              break;
            case 2:
              this.transparency.rgb = this.read(chunkSize);
              break;
          }
          break;
        case "tEXt":
          var text = this.read(chunkSize);
          var index = text.indexOf(0);
          var key = String.fromCharCode.apply(String, text.slice(0, index));
          this.text[key] = String.fromCharCode.apply(
            String,
            text.slice(index + 1)
          );
          break;
        case "IEND":
          switch (this.colorType) {
            case 0:
            case 3:
            case 4:
              this.colors = 1;
              break;
            case 2:
            case 6:
              this.colors = 3;
              break;
          }
          this.hasAlphaChannel = [4, 6].includes(this.colorType);
          var colors = this.colors + (this.hasAlphaChannel ? 1 : 0);
          this.pixelBitlength = this.bits * colors;
          switch (this.colors) {
            case 1:
              this.colorSpace = "DeviceGray";
              break;
            case 3:
              this.colorSpace = "DeviceRGB";
              break;
          }
          this.imgData = new Uint8Array(this.imgData);
          return;
        default:
          this.pos += chunkSize;
      }
      this.pos += 4;
      if (this.pos > this.data.length) {
        throw new Error("Incomplete or corrupt PNG file");
      }
    }
  }
  read(bytes) {
    const result = new Array(bytes);
    for (let i = 0; i < bytes; i++) {
      result[i] = this.data[this.pos++];
    }
    return result;
  }
  readUInt32() {
    const b1 = this.data[this.pos++] << 24;
    const b2 = this.data[this.pos++] << 16;
    const b3 = this.data[this.pos++] << 8;
    const b4 = this.data[this.pos++];
    return b1 | b2 | b3 | b4;
  }
  readUInt16() {
    const b1 = this.data[this.pos++] << 8;
    const b2 = this.data[this.pos++];
    return b1 | b2;
  }
  decodePixels(fn) {
    return inflate(new Uint8Array(this.imgData), (err, data) => {
      if (err) {
        throw err;
      }
      const { width, height } = this;
      const pixelBytes = this.pixelBitlength / 8;
      const pixels = new Uint8Array(width * height * pixelBytes);
      const { length } = data;
      let pos = 0;
      function pass(x0, y0, dx, dy, singlePass = false) {
        const w = Math.ceil((width - x0) / dx);
        const h = Math.ceil((height - y0) / dy);
        const scanlineLength = pixelBytes * w;
        const buffer = singlePass ? pixels : new Uint8Array(scanlineLength * h);
        let row = 0;
        let c = 0;
        while (row < h && pos < length) {
          var byte, col, i, left, upper;
          switch (data[pos++]) {
            case 0:
              for (i = 0; i < scanlineLength; i++) {
                buffer[c++] = data[pos++];
              }
              break;
            case 1:
              for (i = 0; i < scanlineLength; i++) {
                byte = data[pos++];
                left = i < pixelBytes ? 0 : buffer[c - pixelBytes];
                buffer[c++] = (byte + left) % 256;
              }
              break;
            case 2:
              for (i = 0; i < scanlineLength; i++) {
                byte = data[pos++];
                col = (i - i % pixelBytes) / pixelBytes;
                upper = row && buffer[(row - 1) * scanlineLength + col * pixelBytes + i % pixelBytes];
                buffer[c++] = (upper + byte) % 256;
              }
              break;
            case 3:
              for (i = 0; i < scanlineLength; i++) {
                byte = data[pos++];
                col = (i - i % pixelBytes) / pixelBytes;
                left = i < pixelBytes ? 0 : buffer[c - pixelBytes];
                upper = row && buffer[(row - 1) * scanlineLength + col * pixelBytes + i % pixelBytes];
                buffer[c++] = (byte + Math.floor((left + upper) / 2)) % 256;
              }
              break;
            case 4:
              for (i = 0; i < scanlineLength; i++) {
                var paeth, upperLeft;
                byte = data[pos++];
                col = (i - i % pixelBytes) / pixelBytes;
                left = i < pixelBytes ? 0 : buffer[c - pixelBytes];
                if (row === 0) {
                  upper = upperLeft = 0;
                } else {
                  upper = buffer[(row - 1) * scanlineLength + col * pixelBytes + i % pixelBytes];
                  upperLeft = col && buffer[(row - 1) * scanlineLength + (col - 1) * pixelBytes + i % pixelBytes];
                }
                const p = left + upper - upperLeft;
                const pa = Math.abs(p - left);
                const pb = Math.abs(p - upper);
                const pc = Math.abs(p - upperLeft);
                if (pa <= pb && pa <= pc) {
                  paeth = left;
                } else if (pb <= pc) {
                  paeth = upper;
                } else {
                  paeth = upperLeft;
                }
                buffer[c++] = (byte + paeth) % 256;
              }
              break;
            default:
              throw new Error(`Invalid filter algorithm: ${data[pos - 1]}`);
          }
          if (!singlePass) {
            let pixelsPos = ((y0 + row * dy) * width + x0) * pixelBytes;
            let bufferPos = row * scanlineLength;
            for (i = 0; i < w; i++) {
              for (let j = 0; j < pixelBytes; j++)
                pixels[pixelsPos++] = buffer[bufferPos++];
              pixelsPos += (dx - 1) * pixelBytes;
            }
          }
          row++;
        }
      }
      if (this.interlaceMethod === 1) {
        pass(0, 0, 8, 8);
        pass(4, 0, 8, 8);
        pass(0, 4, 4, 8);
        pass(2, 0, 4, 4);
        pass(0, 2, 2, 4);
        pass(1, 0, 2, 2);
        pass(0, 1, 1, 2);
      } else {
        pass(0, 0, 1, 1, true);
      }
      return fn(pixels);
    });
  }
  decodePalette() {
    const { palette } = this;
    const { length } = palette;
    const transparency = this.transparency.indexed || [];
    const ret = new Uint8Array(transparency.length + length);
    let pos = 0;
    let c = 0;
    for (let i = 0; i < length; i += 3) {
      var left;
      ret[pos++] = palette[i];
      ret[pos++] = palette[i + 1];
      ret[pos++] = palette[i + 2];
      ret[pos++] = (left = transparency[c++]) != null ? left : 255;
    }
    return ret;
  }
  copyToImageData(imageData, pixels) {
    let j, k;
    let { colors } = this;
    let palette = null;
    let alpha = this.hasAlphaChannel;
    if (this.palette.length) {
      palette = this._decodedPalette || (this._decodedPalette = this.decodePalette());
      colors = 4;
      alpha = true;
    }
    const data = imageData.data || imageData;
    const { length } = data;
    const input = palette || pixels;
    let i = j = 0;
    if (colors === 1) {
      while (i < length) {
        k = palette ? pixels[i / 4] * 4 : j;
        const v = input[k++];
        data[i++] = v;
        data[i++] = v;
        data[i++] = v;
        data[i++] = alpha ? input[k++] : 255;
        j = k;
      }
    } else {
      while (i < length) {
        k = palette ? pixels[i / 4] * 4 : j;
        data[i++] = input[k++];
        data[i++] = input[k++];
        data[i++] = input[k++];
        data[i++] = alpha ? input[k++] : 255;
        j = k;
      }
    }
  }
  decode(fn) {
    const ret = new Uint8Array(this.width * this.height * 4);
    return this.decodePixels((pixels) => {
      this.copyToImageData(ret, pixels);
      return fn(ret);
    });
  }
};
export {
  PNG$1 as P
};
