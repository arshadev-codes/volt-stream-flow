const G = "G";
const Svg = "SVG";
const View = "VIEW";
const Text = "TEXT";
const Link = "LINK";
const Page = "PAGE";
const Note = "NOTE";
const Path = "PATH";
const Rect = "RECT";
const Line = "LINE";
const FieldSet = "FIELD_SET";
const TextInput = "TEXT_INPUT";
const Select = "SELECT";
const Checkbox = "CHECKBOX";
const List = "LIST";
const Stop = "STOP";
const Defs = "DEFS";
const Image = "IMAGE";
const ImageBackground = "IMAGE_BACKGROUND";
const Tspan = "TSPAN";
const Canvas = "CANVAS";
const Circle = "CIRCLE";
const Ellipse = "ELLIPSE";
const Polygon = "POLYGON";
const Document = "DOCUMENT";
const Polyline = "POLYLINE";
const ClipPath = "CLIP_PATH";
const TextInstance = "TEXT_INSTANCE";
const LinearGradient = "LINEAR_GRADIENT";
const RadialGradient = "RADIAL_GRADIENT";
const Marker = "MARKER";
export {
  Canvas as C,
  Defs as D,
  Ellipse as E,
  FieldSet as F,
  G,
  Image as I,
  Line as L,
  Marker as M,
  Note as N,
  Page as P,
  RadialGradient as R,
  Select as S,
  Text as T,
  View as V,
  Checkbox as a,
  Circle as b,
  ClipPath as c,
  Document as d,
  ImageBackground as e,
  LinearGradient as f,
  Link as g,
  List as h,
  Path as i,
  Polygon as j,
  Polyline as k,
  Rect as l,
  Stop as m,
  Svg as n,
  TextInput as o,
  TextInstance as p,
  Tspan as q
};
