import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { X } from "../_libs/lucide-react.mjs";
import { c as ResponsiveContainer, a as ComposedChart, C as CartesianGrid, X as XAxis, Y as YAxis, b as ReferenceLine, T as Tooltip, A as Area, L as Line, R as ReferenceDot } from "../_libs/recharts.mjs";
function GraphModal({
  open,
  onClose,
  title,
  children
}) {
  if (!open) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[90] flex items-center justify-center bg-black/60 px-4 py-10 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel relative w-full max-w-6xl p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-lg font-bold tracking-wide text-foreground", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onClose,
          className: "inline-flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card hover:bg-accent",
          "aria-label": "Close",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-[70vh] w-full", children })
  ] }) });
}
function calculateTau(data, tolerance = 0.08, windowSize = 50) {
  const decayValues = data.filter((point) => point.timestamp >= 0);
  let lockedTau = null;
  let finalCurrent = null;
  let lockIndex = null;
  let firstIndex = null;
  let breakAtIndex = null;
  let noiseBreakHit = false;
  const tauValues = [];
  for (let i = 1; i < decayValues.length; i++) {
    const curr = decayValues[i];
    const prev = decayValues[i - 1];
    const di = curr.current - prev.current;
    const dt = (curr.timestamp - prev.timestamp) / 1e3;
    const tau = Math.abs(curr.current / (di / dt || 1e-12));
    if (lockedTau === null) {
      tauValues.push(tau);
      if (tauValues.length > windowSize) tauValues.shift();
      if (tauValues.length === windowSize) {
        const sum = tauValues.reduce((a, b) => a + b, 0);
        const avgTau = sum / windowSize;
        const minTau = Math.min(...tauValues);
        const maxTau = Math.max(...tauValues);
        if (maxTau - minTau <= avgTau * tolerance) {
          lockedTau = avgTau;
          lockIndex = i;
          firstIndex = i - windowSize + 1;
        }
      }
    } else {
      const diffFromLocked = Math.abs(tau - lockedTau);
      if (diffFromLocked > lockedTau * tolerance) {
        finalCurrent = prev.current;
        breakAtIndex = i - 1;
        noiseBreakHit = true;
        break;
      }
      finalCurrent = curr.current;
    }
  }
  if (lockedTau !== null && !noiseBreakHit) {
    finalCurrent = decayValues[decayValues.length - 1].current;
    breakAtIndex = decayValues.length - 1;
  }
  const smoothData = firstIndex !== null && breakAtIndex !== null ? decayValues.slice(firstIndex, breakAtIndex + 1) : [];
  return {
    tau: lockedTau,
    finalCurrent,
    lockIndex,
    firstIndex,
    breakAtIndex,
    decayValues,
    smoothData
  };
}
function calculateFlux(tauResult, R) {
  const { smoothData, tau: lockedTau, finalCurrent } = tauResult;
  if (!R || R <= 0 || lockedTau === null || finalCurrent === null || smoothData.length < 2) {
    return [];
  }
  const anchorIndex = smoothData.length - 1;
  let currentFlux = lockedTau * R * finalCurrent;
  const raw = [];
  raw.push({
    timestamp: smoothData[anchorIndex].timestamp,
    current: smoothData[anchorIndex].current,
    linked_flux: currentFlux
  });
  for (let i = anchorIndex; i > 0; i--) {
    const currentSample = smoothData[i];
    const previousSampleInTime = smoothData[i - 1];
    const dt = (currentSample.timestamp - previousSampleInTime.timestamp) / 1e3;
    const fluxChunk = R * currentSample.current * dt;
    currentFlux = currentFlux + fluxChunk;
    raw.push({
      timestamp: previousSampleInTime.timestamp,
      current: previousSampleInTime.current,
      linked_flux: currentFlux
    });
  }
  raw.reverse();
  const psi0 = raw[0].linked_flux;
  return raw.map((point) => ({
    new_timestamp: point.timestamp,
    current: point.current,
    linked_flux: +(psi0 - point.linked_flux).toFixed(6),
    // psi'(t) — this is what the Flux vs Time graph plots
    psi: +point.linked_flux.toFixed(6)
    // psi(i) — this is what the Flux Curve (magnetic characteristic) plots
  }));
}
function createAnalyzedSample(raw, R) {
  const tauResult = calculateTau(raw);
  const fluxData = calculateFlux(tauResult, R);
  let breakPoint = null;
  if (tauResult.breakAtIndex !== null && tauResult.decayValues[tauResult.breakAtIndex]) {
    const p = tauResult.decayValues[tauResult.breakAtIndex];
    breakPoint = { timestamp: p.timestamp, current: p.current };
  }
  const smoothTimestamps = new Set(tauResult.smoothData.map((p) => p.timestamp));
  const rawDisplay = raw.map((p) => ({
    ...p,
    i_smooth: smoothTimestamps.has(p.timestamp) ? p.current : void 0
  }));
  return { rawDisplay, fluxData, breakPoint, tau: tauResult.tau };
}
function convertCurrentUnit(amps, unit) {
  return unit === "mA" ? amps * 1e3 : amps;
}
const timeUnitLabel = (u) => u === "MS" ? "ms" : "s";
const currentUnitLabel = (u) => u === "mA" ? "mA" : "A";
function timeInDisplayUnit(timestampMs, unit) {
  return unit === "MS" ? timestampMs : timestampMs / 1e3;
}
function buildTicks(minTime, maxTime, unit) {
  if (!isFinite(maxTime) || maxTime <= minTime) return [minTime];
  const span = maxTime - minTime;
  const fiveInUnit = unit === "MS" ? 5e3 : 5;
  const stepFine = unit === "MS" ? 500 : 0.5;
  const stepCoarse = unit === "MS" ? 1e3 : 1;
  const step = span <= fiveInUnit ? stepFine : stepCoarse;
  const start = Math.floor(minTime / step) * step;
  const end = Math.ceil(maxTime / step) * step;
  const out = [];
  for (let t = start; t <= end + 1e-9; t += step) {
    out.push(+t.toFixed(unit === "MS" ? 0 : 2));
  }
  return out;
}
function toChartPoint(p, timeUnit, currentUnit) {
  return {
    time: +timeInDisplayUnit(p.timestamp, timeUnit).toFixed(timeUnit === "MS" ? 0 : 3),
    current: +convertCurrentUnit(p.current, currentUnit).toFixed(currentUnit === "mA" ? 0 : 3),
    voltage: +p.voltage.toFixed(3),
    i_smooth: p.i_smooth === void 0 ? void 0 : +convertCurrentUnit(p.i_smooth, currentUnit).toFixed(currentUnit === "mA" ? 0 : 3)
  };
}
function VoltageCurrentGraph({
  points,
  rawPoints,
  timeUnit,
  currentUnit,
  peakCurrent,
  datasetLabel,
  yScale = "linear",
  breakPoint,
  showVoltage = false,
  showSmoothLine = false
}) {
  const fullData = reactExports.useMemo(
    () => points.map((p) => toChartPoint(p, timeUnit, currentUnit)),
    [points, timeUnit, currentUnit]
  );
  const fullMinT = fullData.length ? fullData[0].time : 0;
  const fullMaxT = fullData.length ? fullData[fullData.length - 1].time : 1;
  const tLabel = timeUnitLabel(timeUnit);
  const iLabel = currentUnitLabel(currentUnit);
  const peakDisplay = +convertCurrentUnit(peakCurrent, currentUnit).toFixed(currentUnit === "mA" ? 0 : 2);
  const [zoom, setZoom] = reactExports.useState(null);
  const clampDomain = reactExports.useCallback((d) => {
    const totalSpan = fullMaxT - fullMinT || 1;
    const minSpan = totalSpan * 5e-3;
    let [lo, hi] = d;
    if (!isFinite(lo) || !isFinite(hi)) return [fullMinT, fullMaxT];
    let span = Math.max(hi - lo, minSpan);
    let mid = (lo + hi) / 2;
    mid = Math.min(Math.max(mid, fullMinT + span / 2), fullMaxT - span / 2);
    lo = Math.max(fullMinT, mid - span / 2);
    hi = Math.min(fullMaxT, mid + span / 2);
    if (hi - lo < minSpan || hi <= lo) return [fullMinT, fullMaxT];
    return [lo, hi];
  }, [fullMinT, fullMaxT]);
  const domain = zoom ?? [fullMinT, fullMaxT];
  const data = reactExports.useMemo(() => {
    if (!zoom) return fullData;
    const [lo, hi] = zoom;
    const filteredFull = fullData.filter(
      (d) => d.time >= lo - 1e-6 && d.time <= hi + 1e-6
    );
    if (rawPoints && rawPoints.length) {
      const detailed = rawPoints.filter((p) => {
        const t = timeInDisplayUnit(p.timestamp, timeUnit);
        return t >= lo - 1e-6 && t <= hi + 1e-6;
      }).map((p) => toChartPoint(p, timeUnit, currentUnit));
      if (detailed.length) {
        const rawMaxT = timeInDisplayUnit(
          rawPoints[rawPoints.length - 1].timestamp,
          timeUnit
        );
        const tailFromFull = fullData.filter(
          (d) => d.time > rawMaxT && d.time <= hi + 1e-6
        );
        return [...detailed, ...tailFromFull];
      }
    }
    return filteredFull.length ? filteredFull : fullData;
  }, [zoom, fullData, rawPoints, timeUnit, currentUnit]);
  const visibleCurrentMax = reactExports.useMemo(() => {
    if (!data.length) return peakDisplay || 1;
    return Math.max(...data.map((d) => d.current), 0);
  }, [data, peakDisplay]);
  const leftDomain = zoom ? [0, Math.max(visibleCurrentMax, 1e-3) * 1.1] : [0, Math.max(fullData.length ? Math.max(...fullData.map((d) => d.current)) : 0, peakDisplay) * 1.08];
  const logTicks = reactExports.useMemo(() => {
    if (yScale !== "log") return void 0;
    const maxVal = Math.max(data.length ? Math.max(...data.map((d) => d.current)) : 1, peakDisplay, 1);
    const arr = [];
    let t = 1;
    while (t <= maxVal * 2) {
      arr.push(t);
      t *= 10;
    }
    return arr;
  }, [yScale, data, peakDisplay]);
  const ticks = reactExports.useMemo(() => buildTicks(domain[0], domain[1], timeUnit), [domain, timeUnit]);
  const containerRef = reactExports.useRef(null);
  const pinchStateRef = reactExports.useRef(null);
  const gestureActiveRef = reactExports.useRef(false);
  const zoomAround = reactExports.useCallback((center, factor, base) => {
    const [lo, hi] = base;
    const span = hi - lo;
    const newSpan = Math.max(span * factor, (fullMaxT - fullMinT) * 5e-3);
    const ratio = (center - lo) / (span || 1);
    const newLo = center - newSpan * ratio;
    const newHi = newLo + newSpan;
    return clampDomain([newLo, newHi]);
  }, [clampDomain, fullMaxT, fullMinT]);
  reactExports.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0) return;
      const relX = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
      const base = zoom ?? [fullMinT, fullMaxT];
      const center = base[0] + relX * (base[1] - base[0]);
      const factor = e.deltaY > 0 ? 1.15 : 0.87;
      const next = zoomAround(center, factor, base);
      if (next[0] <= fullMinT + 1e-6 && next[1] >= fullMaxT - 1e-6) setZoom(null);
      else setZoom(next);
    };
    const dist = (touches) => {
      const [a, b] = [touches[0], touches[1]];
      return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    };
    const onTouchStart = (e) => {
      gestureActiveRef.current = true;
      document.body.style.overflow = "hidden";
      if (e.touches.length === 2) {
        e.preventDefault();
        pinchStateRef.current = { startDist: dist(e.touches), startDomain: zoom ?? [fullMinT, fullMaxT] };
      }
    };
    const onTouchMove = (e) => {
      if (gestureActiveRef.current) e.preventDefault();
      if (e.touches.length === 2 && pinchStateRef.current) {
        const rect = el.getBoundingClientRect();
        if (rect.width <= 0) return;
        const currentDist = dist(e.touches);
        const { startDist, startDomain } = pinchStateRef.current;
        if (startDist <= 0) return;
        const factor = startDist / currentDist;
        const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
        const relX = Math.min(1, Math.max(0, (midX - rect.left) / rect.width));
        const center = startDomain[0] + relX * (startDomain[1] - startDomain[0]);
        const next = zoomAround(center, factor, startDomain);
        if (next[0] <= fullMinT + 1e-6 && next[1] >= fullMaxT - 1e-6) setZoom(null);
        else setZoom(next);
      }
    };
    const onTouchEnd = (e) => {
      if (e.touches.length < 2) pinchStateRef.current = null;
      if (e.touches.length === 0) {
        gestureActiveRef.current = false;
        document.body.style.overflow = "";
      }
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("touchstart", onTouchStart, { passive: false });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd, { passive: false });
    el.addEventListener("touchcancel", onTouchEnd, { passive: false });
    return () => {
      el.removeEventListener("wheel", onWheel);
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("touchcancel", onTouchEnd);
      document.body.style.overflow = "";
    };
  }, [zoom, fullMinT, fullMaxT, zoomAround]);
  const resetZoom = reactExports.useCallback(() => setZoom(null), []);
  if (!points.length) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[460px] w-full items-center justify-center rounded-md border border-dashed border-border text-sm text-muted-foreground", children: "No data captured yet." });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-[460px] w-full", style: { minHeight: 460 }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: "Scroll or pinch on the graph to zoom" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        zoom && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: resetZoom,
            className: "rounded-sm border border-border bg-card px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.2em] text-foreground hover:bg-accent",
            children: "Reset Zoom"
          }
        ),
        datasetLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-sm border border-border bg-card px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: datasetLabel })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref: containerRef,
        onDoubleClick: resetZoom,
        style: { touchAction: "none", overscrollBehavior: "contain", height: 460 - 28, minHeight: 300, width: "100%", overflow: "hidden", position: "relative" },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", minHeight: 300, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(ComposedChart, { data, margin: { top: 20, right: 32, left: 12, bottom: 24 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "currentFill", x1: "0", y1: "0", x2: "0", y2: "1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "var(--current)", stopOpacity: 0.55 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "var(--current)", stopOpacity: 0.02 })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { stroke: "var(--grid-line)", strokeDasharray: "2 4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            XAxis,
            {
              type: "number",
              dataKey: "time",
              domain,
              allowDataOverflow: true,
              ticks,
              stroke: "var(--muted-foreground)",
              tick: { fill: "var(--muted-foreground)", fontSize: 11, fontFamily: "var(--font-mono)" },
              tickFormatter: (v) => timeUnit === "MS" ? `${v}` : v.toFixed(1),
              label: { value: `Time (${tLabel})`, position: "insideBottom", offset: -10, fill: "var(--foreground)", fontSize: 12, fontWeight: 700, fontFamily: "var(--font-display)" }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            YAxis,
            {
              scale: yScale,
              domain: yScale === "log" ? [1, "auto"] : leftDomain,
              ticks: logTicks,
              allowDataOverflow: true,
              stroke: "var(--current)",
              tick: { fill: "var(--current)", fontSize: 11, fontFamily: "var(--font-mono)" },
              tickFormatter: (v) => Number(v).toFixed(0),
              label: { value: `Current (${iLabel})`, angle: -90, position: "insideLeft", fill: "var(--current)", fontSize: 12, fontWeight: 700, fontFamily: "var(--font-display)" }
            }
          ),
          showVoltage && /* @__PURE__ */ jsxRuntimeExports.jsx(
            YAxis,
            {
              yAxisId: "voltage",
              orientation: "right",
              stroke: "#38bdf8",
              tick: { fill: "#38bdf8", fontSize: 11, fontFamily: "var(--font-mono)" },
              label: { value: "Voltage (V)", angle: 90, position: "insideRight", fill: "#38bdf8", fontSize: 12, fontWeight: 700, fontFamily: "var(--font-display)" }
            }
          ),
          peakDisplay > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
            ReferenceLine,
            {
              y: peakDisplay,
              stroke: "var(--peak)",
              strokeDasharray: "4 4",
              label: { value: `Peak ${peakDisplay} ${iLabel}`, fill: "var(--peak)", fontSize: 11, fontFamily: "var(--font-mono)", position: "insideTopRight" }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Tooltip,
            {
              contentStyle: { background: "color-mix(in oklab, var(--popover) 96%, transparent)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--popover-foreground)", boxShadow: "0 10px 30px -10px rgba(0,0,0,0.5)" },
              labelStyle: { color: "var(--foreground)", fontWeight: 700 },
              labelFormatter: (v) => `t = ${timeUnit === "MS" ? v : Number(v).toFixed(3)} ${tLabel}`,
              formatter: ((value) => [`${value} ${iLabel}`, "Current"])
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Area,
            {
              type: "monotone",
              dataKey: "current",
              name: `Current (${iLabel})`,
              stroke: "var(--current)",
              strokeWidth: 2.4,
              fill: "url(#currentFill)",
              isAnimationActive: false,
              dot: false,
              activeDot: { r: 4, strokeWidth: 2, stroke: "var(--background)" }
            }
          ),
          showSmoothLine && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Line,
            {
              type: "monotone",
              dataKey: "i_smooth",
              name: "Locked / smooth region",
              stroke: "#00e5ff",
              strokeWidth: 3.5,
              dot: false,
              connectNulls: false,
              isAnimationActive: false
            }
          ),
          showVoltage && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Line,
            {
              yAxisId: "voltage",
              type: "monotone",
              dataKey: "voltage",
              name: "Voltage (V)",
              stroke: "#38bdf8",
              strokeWidth: 2,
              dot: false,
              isAnimationActive: false
            }
          ),
          breakPoint && /* @__PURE__ */ jsxRuntimeExports.jsx(
            ReferenceDot,
            {
              x: +timeInDisplayUnit(breakPoint.timestamp, timeUnit).toFixed(timeUnit === "MS" ? 0 : 3),
              y: +convertCurrentUnit(breakPoint.current, currentUnit).toFixed(currentUnit === "mA" ? 0 : 3),
              r: 6,
              fill: "black",
              stroke: "white",
              label: { value: "Break", position: "top", fill: "var(--foreground)", fontSize: 11 }
            }
          )
        ] }) })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 flex items-center justify-between px-2 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
        "Window: ",
        timeUnit === "MS" ? domain[0].toFixed(0) : domain[0].toFixed(2),
        " → ",
        timeUnit === "MS" ? domain[1].toFixed(0) : domain[1].toFixed(2),
        " ",
        tLabel
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
        data.length,
        " packets in view"
      ] })
    ] })
  ] });
}
export {
  GraphModal as G,
  VoltageCurrentGraph as V,
  createAnalyzedSample as a,
  currentUnitLabel as b,
  convertCurrentUnit as c,
  timeUnitLabel as t
};
