import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useTheme, B as BrandHeader, g as getSettings, s as subscribeSettings } from "./settings-BuFBVS38.mjs";
import { l as logo } from "./router-KWJ3Ta83.mjs";
import { b as currentUnitLabel, G as GraphModal, a as createAnalyzedSample, V as VoltageCurrentGraph, c as convertCurrentUnit, t as timeUnitLabel } from "./VoltageCurrentGraph-BHuYz0x4.mjs";
import { u as useTestObjects, h as computeTimeConstant, j as computeUltimateDcVoltage, a as computeMagneticCharacteristicPu, i as computeTimeToSteadyState } from "./reactorCalcs-BDTazTR4.mjs";
import { u as useSettings } from "./useSettings-CguaxJl3.mjs";
import { R as Root2, L as List, T as Trigger, C as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { b as CircleCheck, L as LoaderCircle, i as PlugZap, p as TriangleAlert, G as Gauge, M as Maximize2, S as Search, C as ChevronDown, n as ShieldCheck, m as ShieldAlert, c as CircleX, R as Radio, W as WifiOff, k as RotateCcw, a as Circle } from "../_libs/lucide-react.mjs";
import { m as motion, A as AnimatePresence } from "../_libs/framer-motion.mjs";
import { c as ResponsiveContainer, a as ComposedChart, C as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, A as Area } from "../_libs/recharts.mjs";
import { H as HubConnectionBuilder, a as HubConnectionState } from "../_libs/microsoft__signalr.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/gsap.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
import "../_libs/es-toolkit.mjs";
import "../_libs/reselect.mjs";
import "../_libs/d3-shape.mjs";
import "../_libs/d3-path.mjs";
import "../_libs/reduxjs__toolkit.mjs";
import "../_libs/redux.mjs";
import "../_libs/immer.mjs";
import "../_libs/redux-thunk.mjs";
import "../_libs/react-redux.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/victory-vendor.mjs";
import "../_libs/d3-scale.mjs";
import "../_libs/internmap.mjs";
import "../_libs/d3-array.mjs";
import "../_libs/d3-time-format.mjs";
import "../_libs/d3-time.mjs";
import "../_libs/d3-interpolate.mjs";
import "../_libs/d3-color.mjs";
import "../_libs/d3-format.mjs";
import "../_libs/decimal.js-light.mjs";
import "../_libs/eventemitter3.mjs";
const MAP = {
  idle: { label: "IDLE", color: "var(--muted-foreground)" },
  ramp_up: { label: "CHARGING", color: "var(--current)" },
  decay: { label: "DISCHARGING", color: "var(--voltage)" },
  completed: { label: "COMPLETED", color: "var(--ok)" }
};
function StatusBadge({ status }) {
  const s = MAP[status];
  const animated = status === "ramp_up" || status === "decay";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "inline-flex items-center gap-2 rounded-md border px-3 py-1.5 font-mono text-[11px] font-bold tracking-[0.2em]",
      style: {
        color: s.color,
        borderColor: `color-mix(in oklab, ${s.color} 40%, var(--border))`,
        background: `color-mix(in oklab, ${s.color} 10%, var(--card))`
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.span,
          {
            className: "h-2 w-2 rounded-full",
            style: { background: s.color, boxShadow: `0 0 8px ${s.color}` },
            animate: animated ? { opacity: [1, 0.3, 1], scale: [1, 1.25, 1] } : { opacity: 1 },
            transition: { duration: 1.1, repeat: Infinity }
          }
        ),
        s.label
      ]
    }
  );
}
function TestController({
  status,
  connected: connected2,
  timeUnit,
  currentUnit,
  onClear,
  onTimeUnitChange,
  onCurrentUnitChange,
  showVoltage,
  onShowVoltageChange,
  showSmoothLine,
  onShowSmoothLineChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel flex flex-wrap items-center gap-3 p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status }),
    connected2 ? status === "idle" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 font-mono text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Radio, { className: "h-3.5 w-3.5 animate-pulse" }),
      " Waiting for bench start…"
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 font-mono text-xs text-destructive", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "h-3.5 w-3.5" }),
      " Backend not connected"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ml-auto flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(UnitSelect, { label: "Time", value: timeUnit, options: [["S", "Seconds"], ["MS", "Milliseconds"]], onChange: (v) => onTimeUnitChange(v) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(UnitSelect, { label: "Current", value: currentUnit, options: [["A", "Amperes"], ["mA", "Milliamps"]], onChange: (v) => onCurrentUnitChange(v) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(GraphToggle, { label: "Voltage", checked: showVoltage, onChange: onShowVoltageChange }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(GraphToggle, { label: "Steady State", checked: showSmoothLine, onChange: onShowSmoothLineChange }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: onClear,
          className: "inline-flex items-center gap-2 rounded-md border border-border bg-secondary px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-secondary-foreground transition hover:bg-accent",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5" }),
            " Clear"
          ]
        }
      )
    ] })
  ] });
}
function GraphToggle({
  label,
  checked,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 rounded-md border border-border bg-card px-2 py-1.5 font-mono text-[11px] cursor-pointer select-none", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type: "checkbox",
        checked,
        onChange: (e) => onChange(e.target.checked),
        className: "h-3.5 w-3.5 accent-[var(--current)]"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold uppercase tracking-wider text-muted-foreground", children: label })
  ] });
}
function UnitSelect({
  label,
  value,
  options,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 rounded-md border border-border bg-card px-2 py-1.5 font-mono text-[11px]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold uppercase tracking-wider text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "select",
      {
        value,
        onChange: (e) => onChange(e.target.value),
        className: "bg-transparent font-semibold text-foreground outline-none",
        children: options.map(([v, l]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: v, className: "bg-popover text-popover-foreground", children: [
          l,
          " (",
          v,
          ")"
        ] }, v))
      }
    )
  ] });
}
const ITEMS = [
  { key: "acbOn", label: "ACB", goodWhen: true, goodLabel: "ON", badLabel: "OFF" },
  { key: "acbTrip", label: "ACB TRIP", goodWhen: false, goodLabel: "CLEAR", badLabel: "TRIPPED" },
  { key: "emgHealthy", label: "EMERGENCY", goodWhen: true, goodLabel: "HEALTHY", badLabel: "TRIGGERED" },
  { key: "dcTrip", label: "DC TRIP", goodWhen: false, goodLabel: "CLEAR", badLabel: "TRIPPED" }
];
function InterlockStatusPanel({ status }) {
  const prevRef = reactExports.useRef(null);
  const [alert, setAlert] = reactExports.useState(null);
  reactExports.useEffect(() => {
    const prev = prevRef.current;
    prevRef.current = status;
    if (!prev) return;
    for (const item of ITEMS) {
      if (prev[item.key] !== status[item.key]) {
        const isGood = status[item.key] === item.goodWhen;
        setAlert({
          text: `${item.label} → ${isGood ? item.goodLabel : item.badLabel}`,
          ok: isGood
        });
        const t = setTimeout(() => setAlert(null), 3500);
        return () => clearTimeout(t);
      }
    }
  }, [status]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.2em] text-foreground", children: [
        status.canArm ? /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-4 w-4 text-[var(--ok)]" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "h-4 w-4 text-amber-500" }),
        "Interlock Status"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "span",
        {
          className: `rounded-md border px-3 py-1 font-mono text-[11px] font-bold uppercase tracking-widest ${status.canArm ? "border-[var(--ok)]/40 bg-[var(--ok)]/10 text-[var(--ok)]" : "border-amber-500/40 bg-amber-500/10 text-amber-500"}`,
          children: status.canArm ? "Ready to Arm" : "Not Ready"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: ITEMS.map((item) => {
      const value = status[item.key];
      const isGood = value === item.goodWhen;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `flex items-center gap-2 rounded-md border px-2.5 py-2 font-mono text-[11px] font-bold uppercase tracking-wider transition-colors ${isGood ? "border-[var(--ok)]/40 bg-[var(--ok)]/10 text-[var(--ok)]" : "border-destructive/40 bg-destructive/10 text-destructive"}`,
          children: [
            isGood ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-3.5 w-3.5 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
              item.label,
              ": ",
              isGood ? item.goodLabel : item.badLabel
            ] })
          ]
        },
        item.key
      );
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: alert && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: -8 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -8 },
        className: `mt-3 flex items-center gap-2 rounded-md border px-3 py-2 font-mono text-xs ${alert.ok ? "border-[var(--ok)]/40 bg-[var(--ok)]/10 text-[var(--ok)]" : "border-destructive/40 bg-destructive/10 text-destructive"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-3.5 w-3.5 shrink-0" }),
          alert.text
        ]
      }
    ) })
  ] });
}
const accentVar = {
  current: "var(--current)",
  peak: "var(--peak)",
  phase: "var(--voltage)",
  duration: "var(--ok)",
  samples: "var(--chart-5)",
  neutral: "var(--foreground)"
};
function StatCard({ label, value, unit, accent = "neutral" }) {
  const c = accentVar[accent];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 8 },
      animate: { opacity: 1, y: 0 },
      className: "panel relative overflow-hidden p-4",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "pointer-events-none absolute inset-x-0 top-0 h-px",
            style: { background: `linear-gradient(90deg, transparent, ${c}, transparent)` }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "pointer-events-none absolute -inset-px opacity-[0.08]",
            style: { background: `radial-gradient(120% 80% at 0% 0%, ${c}, transparent 60%)` }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 rounded-full", style: { background: c, boxShadow: `0 0 8px ${c}` } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: label })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 font-mono text-2xl font-bold tabular-nums", style: { color: c }, children: [
            value,
            unit && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-sm text-muted-foreground", children: unit })
          ] })
        ] })
      ]
    }
  );
}
function LoadingScreen({ durationMs = 1900 }) {
  const [gone, setGone] = reactExports.useState(false);
  const [fading, setFading] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const f = setTimeout(() => setFading(true), durationMs - 400);
    const g = setTimeout(() => setGone(true), durationMs);
    return () => {
      clearTimeout(f);
      clearTimeout(g);
    };
  }, [durationMs]);
  if (gone) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#06080f] transition-opacity duration-400 ${fading ? "opacity-0" : "opacity-100"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "pointer-events-none absolute inset-0 opacity-[0.07]",
            style: {
              backgroundImage: "linear-gradient(rgba(251,146,60,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(251,146,60,.6) 1px, transparent 1px)",
              backgroundSize: "40px 40px"
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex h-44 w-44 items-center justify-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 200 200", className: "absolute inset-0 h-full w-full", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "bolt", x1: "0", y1: "0", x2: "1", y2: "1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#fde68a" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "60%", stopColor: "#f59e0b" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#ea580c" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "circle",
              {
                cx: "100",
                cy: "100",
                r: "86",
                fill: "none",
                stroke: "url(#bolt)",
                strokeWidth: "1.4",
                strokeDasharray: "6 10",
                className: "esa-spin",
                style: { transformOrigin: "100px 100px" }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "100", cy: "100", r: "70", fill: "none", stroke: "rgba(251,146,60,0.25)", strokeWidth: "1" })
          ] }),
          [0, 60, 120, 180, 240, 300].map((deg, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "absolute h-20 w-px origin-bottom esa-pulse",
              style: {
                transform: `rotate(${deg}deg) translateY(-72px)`,
                background: "linear-gradient(to top, transparent, #f59e0b, #fde68a)",
                animationDelay: `${i * 0.12}s`
              }
            },
            deg
          )),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: logo,
              alt: "Electrosoft Automation",
              className: "relative z-10 h-20 w-20 object-contain drop-shadow-[0_0_18px_rgba(245,158,11,0.55)] esa-glow invert"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold uppercase tracking-[0.55em] text-amber-400/80", children: "Electrosoft Automation" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-lg font-semibold text-slate-100", children: "Reactor Linearity Testing System" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mt-5 h-1 w-56 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full w-1/3 rounded-full bg-gradient-to-r from-amber-300 via-orange-500 to-rose-500 esa-load" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 font-mono text-[10px] tracking-[0.3em] text-slate-500", children: "INITIALIZING · CALIBRATING · ENERGIZING" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("style", { children: `
        @keyframes esaSpin { to { transform: rotate(360deg); } }
        .esa-spin { animation: esaSpin 6s linear infinite; }
        @keyframes esaPulse {
          0%, 100% { opacity: 0.1; transform: scaleY(0.6) rotate(var(--r,0deg)) translateY(-72px); }
          50% { opacity: 1; }
        }
        .esa-pulse { animation: esaPulse 1.4s ease-in-out infinite; }
        @keyframes esaGlow {
          0%,100% { filter: drop-shadow(0 0 12px rgba(245,158,11,.55)) invert(1); }
          50%     { filter: drop-shadow(0 0 26px rgba(253,224,71,.9))  invert(1); }
        }
        .esa-glow { animation: esaGlow 1.6s ease-in-out infinite; }
        @keyframes esaLoad {
          0%   { transform: translateX(-100%); }
          100% { transform: translateX(300%); }
        }
        .esa-load { animation: esaLoad 1.4s ease-in-out infinite; }
      ` })
      ]
    }
  );
}
const STATUS_ICON = {
  pending: /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { className: "h-3.5 w-3.5 text-muted-foreground" }),
  passed: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5 text-[var(--ok)]" }),
  failed: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-3.5 w-3.5 text-destructive" })
};
function TestObjectSearch({ objects, selectedId, onSelect }) {
  const [q, setQ] = reactExports.useState("");
  const [open, setOpen] = reactExports.useState(false);
  const filtered = reactExports.useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return objects;
    return objects.filter(
      (o) => o.serialNumber.toLowerCase().includes(s) || o.name.toLowerCase().includes(s) || (o.manufacturer ?? "").toLowerCase().includes(s)
    );
  }, [q, objects]);
  const selected = objects.find((o) => o.id === selectedId) ?? null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 shadow-sm focus-within:ring-1 focus-within:ring-ring", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4 text-muted-foreground" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          value: q,
          onChange: (e) => {
            setQ(e.target.value);
            setOpen(true);
          },
          onFocus: () => setOpen(true),
          onBlur: () => setTimeout(() => setOpen(false), 150),
          placeholder: selected ? `${selected.serialNumber} · ${selected.name}` : "Search test object…",
          className: "w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
        }
      ),
      selected && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onMouseDown: (e) => {
            e.preventDefault();
            onSelect(null);
            setQ("");
          },
          className: "text-[10px] font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground",
          children: "Clear"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4 text-muted-foreground" })
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-md border border-border bg-popover shadow-lg", children: filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-4 text-center text-xs text-muted-foreground", children: [
      "No test objects. Create one in ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: "Test Objects" }),
      "."
    ] }) : filtered.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onMouseDown: (e) => {
          e.preventDefault();
          onSelect(o.id);
          setOpen(false);
          setQ("");
        },
        className: `flex w-full items-start justify-between gap-3 px-3 py-2 text-left text-sm transition hover:bg-accent ${o.id === selectedId ? "bg-accent" : ""}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-semibold text-foreground", children: [
              STATUS_ICON[o.status],
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: o.serialNumber }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate text-muted-foreground", children: [
                "· ",
                o.name
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 text-[11px] text-muted-foreground", children: [
              o.idcForLinearityTest?.toFixed(2) ?? "—",
              " A target · ",
              o.maxVoltage,
              " V max"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 rounded-sm border border-border bg-card px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground", children: o.status })
        ]
      },
      o.id
    )) })
  ] });
}
function createSignalRSource(config) {
  const connection = new HubConnectionBuilder().withUrl(config.hubUrl).withAutomaticReconnect().build();
  let phase = "ramp_up";
  return {
    async connect() {
      if (connection.state === HubConnectionState.Disconnected) {
        await connection.start();
      }
    },
    async disconnect() {
      await connection.stop();
    },
    triggerDecay() {
    },
    subscribe(handler) {
      let batchBuffer = [];
      let flushHandle = 0;
      const flush = () => {
        if (batchBuffer.length > 0) {
          handler({ batch: batchBuffer, phase });
          batchBuffer = [];
        }
        flushHandle = requestAnimationFrame(flush);
      };
      connection.on(
        "DataPoint",
        (point) => {
          batchBuffer.push({
            timestamp: point.time * 1e3,
            voltage: point.voltage,
            current: point.current,
            phase: 0,
            peak: point.peak
          });
        }
      );
      connection.on("TestStarted", () => {
        phase = "ramp_up";
        handler({ batch: [], phase: "ramp_up", reset: true });
      });
      connection.on("TestStopped", (payload) => {
        phase = "completed";
        handler({ batch: [], phase: "completed", finalPeak: payload?.peak });
      });
      connection.on("TestAborted", (payload) => {
        phase = "completed";
        handler({
          batch: [],
          phase: "completed",
          finalPeak: payload?.peak,
          abortReason: payload?.reason
        });
      });
      connection.on("InterlockStatus", (status) => {
        handler({ batch: [], phase, interlock: status });
      });
      connection.on("HardwareFault", (payload) => {
        handler({ batch: [], phase, hardwareFault: payload?.message ?? "Hardware connection lost." });
      });
      connection.on("HardwareRecovered", () => {
        handler({ batch: [], phase, hardwareRecovered: true });
      });
      flushHandle = requestAnimationFrame(flush);
      return () => {
        cancelAnimationFrame(flushHandle);
        connection.off("DataPoint");
        connection.off("TestStarted");
        connection.off("TestStopped");
        connection.off("TestAborted");
        connection.off("InterlockStatus");
        connection.off("HardwareFault");
        connection.off("HardwareRecovered");
      };
    }
  };
}
const HUB_URL = "http://localhost:5274/hubs/linearity";
let source = null;
let unsubSource = null;
let connected = false;
const eventListeners = /* @__PURE__ */ new Set();
const connectedListeners = /* @__PURE__ */ new Set();
function notifyConnected(v) {
  connected = v;
  connectedListeners.forEach((l) => l(v));
}
function startConnection() {
  if (source) return;
  source = createSignalRSource({ hubUrl: HUB_URL });
  unsubSource = source.subscribe((e) => {
    eventListeners.forEach((l) => l(e));
  });
  source.connect().then(() => notifyConnected(true)).catch(() => notifyConnected(false));
}
function stopConnection() {
  unsubSource?.();
  unsubSource = null;
  source?.disconnect();
  source = null;
  if (connected) notifyConnected(false);
}
function applyDataSource(dataSource) {
  if (dataSource === "live") {
    startConnection();
  } else {
    stopConnection();
  }
}
if (typeof window !== "undefined") {
  applyDataSource(getSettings().dataSource);
  subscribeSettings((s) => applyDataSource(s.dataSource));
}
function subscribeReactorEvents(l) {
  eventListeners.add(l);
  return () => eventListeners.delete(l);
}
function subscribeReactorConnected(l) {
  connectedListeners.add(l);
  l(connected);
  return () => connectedListeners.delete(l);
}
function isReactorConnected() {
  return connected;
}
function analyzeRaw(raw, groupSize = 4) {
  if (raw.length === 0) return [];
  const out = [];
  for (let i = 0; i < raw.length; i += groupSize) {
    const group = raw.slice(i, i + groupSize);
    if (group.length === 0) continue;
    out.push({
      timestamp: +((group[0].timestamp + group[group.length - 1].timestamp) / 2).toFixed(3),
      voltage: median(group.map((p) => p.voltage)),
      current: median(group.map((p) => p.current)),
      phase: median(group.map((p) => p.phase))
    });
  }
  return out;
}
function median(values) {
  const a = [...values].sort((x, y) => x - y);
  const mid = a.length >> 1;
  const m = a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
  return +m.toFixed(4);
}
const DEFAULT_INTERLOCK = {
  acbOn: false,
  acbTrip: false,
  emgHealthy: false,
  dcTrip: false,
  canArm: false
};
function useReactorTesting() {
  const [raw, setRaw] = reactExports.useState([]);
  const [analysis, setAnalysis] = reactExports.useState([]);
  const [phase, setPhase] = reactExports.useState("idle");
  const [connected2, setConnected] = reactExports.useState(isReactorConnected());
  const [startedAt, setStartedAt] = reactExports.useState(null);
  const [duration, setDuration] = reactExports.useState(0);
  const [peakCurrent, setPeakCurrent] = reactExports.useState(0);
  const [interlock, setInterlock] = reactExports.useState(DEFAULT_INTERLOCK);
  const [abortReason, setAbortReason] = reactExports.useState(null);
  const [hardwareFault, setHardwareFault] = reactExports.useState(null);
  const rawRef = reactExports.useRef([]);
  const peakRef = reactExports.useRef(0);
  const reset = reactExports.useCallback(() => {
    rawRef.current = [];
    peakRef.current = 0;
    setRaw([]);
    setAnalysis([]);
    setDuration(0);
    setStartedAt(null);
    setPeakCurrent(0);
    setPhase("idle");
    setAbortReason(null);
  }, []);
  reactExports.useEffect(() => {
    const unsubEvents = subscribeReactorEvents((e) => {
      if (e.interlock) {
        setInterlock(e.interlock);
      }
      if (e.hardwareFault) {
        setHardwareFault(e.hardwareFault);
      }
      if (e.hardwareRecovered) {
        setHardwareFault(null);
      }
      if (e.reset) {
        rawRef.current = [];
        peakRef.current = 0;
        setRaw([]);
        setAnalysis([]);
        setPeakCurrent(0);
        setDuration(0);
        setStartedAt(Date.now());
        setPhase("ramp_up");
        setAbortReason(null);
        return;
      }
      if (e.batch.length) {
        rawRef.current = rawRef.current.concat(e.batch);
        let batchMax = peakRef.current;
        for (const p of e.batch) {
          if (p.current > batchMax) batchMax = p.current;
        }
        const last = e.batch[e.batch.length - 1];
        if (typeof last.peak === "number" && last.peak > batchMax) {
          batchMax = last.peak;
        }
        if (batchMax > peakRef.current) {
          peakRef.current = batchMax;
          setPeakCurrent(batchMax);
        }
        setRaw(rawRef.current);
      }
      if (e.phase === "completed") {
        setPhase("completed");
        setAnalysis(analyzeRaw(rawRef.current));
        if (typeof e.finalPeak === "number" && e.finalPeak > peakRef.current) {
          peakRef.current = e.finalPeak;
          setPeakCurrent(e.finalPeak);
        }
        if (e.abortReason) {
          setAbortReason(e.abortReason);
        }
      }
    });
    const unsubConnected = subscribeReactorConnected(setConnected);
    return () => {
      unsubEvents();
      unsubConnected();
    };
  }, []);
  reactExports.useEffect(() => {
    if (!startedAt || phase !== "ramp_up") return;
    const id = setInterval(() => setDuration((Date.now() - startedAt) / 1e3), 200);
    return () => clearInterval(id);
  }, [startedAt, phase]);
  const latest = raw[raw.length - 1];
  return {
    raw,
    analysis,
    phase,
    connected: connected2,
    duration,
    latestCurrent: latest?.current ?? 0,
    latestVoltage: latest?.voltage ?? 0,
    peakCurrent,
    totalSamples: raw.length,
    interlock,
    abortReason,
    hardwareFault,
    reset
  };
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const Tabs = Root2;
const TabsList = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  List,
  {
    ref,
    className: cn(
      "inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground",
      className
    ),
    ...props
  }
));
TabsList.displayName = List.displayName;
const TabsTrigger = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Trigger,
  {
    ref,
    className: cn(
      "inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow",
      className
    ),
    ...props
  }
));
TabsTrigger.displayName = Trigger.displayName;
const TabsContent = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Content,
  {
    ref,
    className: cn(
      "mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
      className
    ),
    ...props
  }
));
TabsContent.displayName = Content.displayName;
function FluxCurveGraph({ fluxData, currentUnit, resistance, scale, puData, tau, hasRawSamples }) {
  const iLabel = currentUnitLabel(currentUnit);
  const isPu = !!puData && puData.length >= 2;
  const data = reactExports.useMemo(() => {
    if (isPu) {
      return puData.map((p) => ({ current: +p.CurrentPu.toFixed(5), psi: +p.FluxPU.toFixed(5) })).filter((d) => scale === "log" ? d.current > 0 : true).sort((a, b) => a.current - b.current);
    }
    return fluxData.map((f) => ({
      current: +convertCurrentUnit(f.current, currentUnit).toFixed(4),
      psi: f.psi
    })).filter((d) => scale === "log" ? d.current > 0 : true).sort((a, b) => a.current - b.current);
  }, [fluxData, puData, isPu, currentUnit, scale]);
  if (!isPu && !resistance) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[460px] w-full items-center justify-center rounded-md border border-dashed border-border text-sm text-muted-foreground", children: "No resistance (R) set on this test object — flux curve can't be calculated." });
  }
  if (data.length < 2) {
    const message = hasRawSamples && tau === null ? "Tau did not lock — this doesn't look like a clean exponential decay. Check the reactor is connected, or review the raw waveform tab." : "No data captured yet.";
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[460px] w-full items-center justify-center rounded-md border border-dashed border-border text-sm text-muted-foreground", children: message });
  }
  const xLabel = isPu ? "Current (p.u.)" : `Current (${iLabel})`;
  const yLabel = isPu ? "Linked Flux ψ (p.u.)" : "ψ (Wb-turns)";
  const headerText = isPu ? `ψ vs i — per-unit (IEC 60076-6 Figure B.6)` : `ψ vs i (${scale} scale) — IEC 60076-6 Annex B.7.1 · R = ${resistance} Ω`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-[460px] w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: headerText }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "92%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(ComposedChart, { data, margin: { top: 20, right: 32, left: 12, bottom: 24 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "psiFillCurrent", x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "var(--current)", stopOpacity: 0.55 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "var(--current)", stopOpacity: 0.02 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { stroke: "var(--grid-line)", strokeDasharray: "2 4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        XAxis,
        {
          type: "number",
          dataKey: "current",
          scale,
          allowDataOverflow: true,
          domain: scale === "log" ? ["auto", "auto"] : [0, "auto"],
          stroke: "var(--muted-foreground)",
          tick: { fill: "var(--muted-foreground)", fontSize: 11, fontFamily: "var(--font-mono)" },
          label: {
            value: xLabel,
            position: "insideBottom",
            offset: -10,
            fill: "var(--foreground)",
            fontSize: 12,
            fontWeight: 700,
            fontFamily: "var(--font-display)"
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        YAxis,
        {
          type: "number",
          dataKey: "psi",
          stroke: "var(--current)",
          tick: { fill: "var(--current)", fontSize: 11, fontFamily: "var(--font-mono)" },
          label: {
            value: yLabel,
            angle: -90,
            position: "insideLeft",
            fill: "var(--current)",
            fontSize: 12,
            fontWeight: 700,
            fontFamily: "var(--font-display)"
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Tooltip,
        {
          contentStyle: {
            background: "color-mix(in oklab, var(--popover) 96%, transparent)",
            border: "1px solid var(--border)",
            borderRadius: 6,
            fontSize: 12,
            fontFamily: "var(--font-mono)",
            color: "var(--popover-foreground)"
          },
          formatter: ((v) => [isPu ? `${v} pu` : `${v} Wb-t`, "ψ"]),
          labelFormatter: (v) => `i = ${v} ${isPu ? "pu" : iLabel}`
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Area,
        {
          type: "monotone",
          dataKey: "psi",
          stroke: "var(--current)",
          strokeWidth: 2.2,
          fill: "url(#psiFillCurrent)",
          isAnimationActive: false,
          dot: false
        }
      )
    ] }) })
  ] });
}
function FluxTimeGraph({ fluxData, timeUnit, resistance }) {
  const tLabel = timeUnitLabel(timeUnit);
  const data = reactExports.useMemo(() => {
    return fluxData.map((f) => ({
      time: timeUnit === "MS" ? f.new_timestamp : f.new_timestamp / 1e3,
      psi: f.linked_flux
      // ψ'(t) — accumulated flux since t=0
    }));
  }, [fluxData, timeUnit]);
  if (!resistance || data.length < 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[460px] w-full items-center justify-center rounded-md border border-dashed border-border text-sm text-muted-foreground", children: !resistance ? "No resistance (R) set." : "No data captured yet." });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-[460px] w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: [
      "ψ vs Time — IEC 60076-6 Fig B.5 · R = ",
      resistance,
      " Ω"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "92%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(ComposedChart, { data, margin: { top: 20, right: 32, left: 12, bottom: 24 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "psiFillTime", x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "var(--current)", stopOpacity: 0.55 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "var(--current)", stopOpacity: 0.02 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { stroke: "var(--grid-line)", strokeDasharray: "2 4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        XAxis,
        {
          type: "number",
          dataKey: "time",
          domain: ["auto", "auto"],
          stroke: "var(--muted-foreground)",
          tick: { fill: "var(--muted-foreground)", fontSize: 11, fontFamily: "var(--font-mono)" },
          label: {
            value: `Time (${tLabel})`,
            position: "insideBottom",
            offset: -10,
            fill: "var(--foreground)",
            fontSize: 12,
            fontWeight: 700,
            fontFamily: "var(--font-display)"
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        YAxis,
        {
          type: "number",
          dataKey: "psi",
          stroke: "var(--current)",
          tick: { fill: "var(--current)", fontSize: 11, fontFamily: "var(--font-mono)" },
          label: {
            value: "ψ Linked Flux (Wb-turns)",
            angle: -90,
            position: "insideLeft",
            fill: "var(--current)",
            fontSize: 12,
            fontWeight: 700,
            fontFamily: "var(--font-display)"
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Tooltip,
        {
          contentStyle: {
            background: "color-mix(in oklab, var(--popover) 96%, transparent)",
            border: "1px solid var(--border)",
            borderRadius: 6,
            fontSize: 12,
            fontFamily: "var(--font-mono)",
            color: "var(--popover-foreground)"
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Area,
        {
          type: "monotone",
          dataKey: "psi",
          stroke: "var(--current)",
          strokeWidth: 2.2,
          fill: "url(#psiFillTime)",
          isAnimationActive: false,
          dot: false
        }
      )
    ] }) })
  ] });
}
function LinearityGraphTabs({
  points,
  rawPoints,
  timeUnit,
  currentUnit,
  peakCurrent,
  datasetLabel,
  resistance,
  inductance,
  ratedAcRmsCurrent,
  showVoltage,
  showSmoothLine
}) {
  const analyzed = reactExports.useMemo(
    () => createAnalyzedSample(points, resistance ?? 0),
    [points, resistance]
  );
  const puData = reactExports.useMemo(
    () => computeMagneticCharacteristicPu(analyzed.fluxData, inductance ?? 0, ratedAcRmsCurrent ?? 0),
    [analyzed.fluxData, inductance, ratedAcRmsCurrent]
  );
  const dischargeDisplay = analyzed.rawDisplay.filter((p) => p.timestamp >= 0);
  const hasRawSamples = points.length > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "raw", className: "w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "mb-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "raw", className: "font-mono text-[11px] uppercase tracking-wider", children: "Time VS Current" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "raw-log", className: "font-mono text-[11px] uppercase tracking-wider", children: "Logarithmic Scaling" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "flux-time", className: "font-mono text-[11px] uppercase tracking-wider", children: "Flux Calculation" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TabsTrigger, { value: "flux-linear", className: "font-mono text-[11px] uppercase tracking-wider", children: "Magnetic Characteristic" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "raw", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      VoltageCurrentGraph,
      {
        points: analyzed.rawDisplay,
        rawPoints,
        timeUnit,
        currentUnit,
        peakCurrent,
        datasetLabel,
        breakPoint: analyzed.breakPoint,
        showVoltage,
        showSmoothLine
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "raw-log", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      VoltageCurrentGraph,
      {
        points: dischargeDisplay,
        rawPoints: dischargeDisplay,
        timeUnit,
        currentUnit,
        peakCurrent,
        datasetLabel,
        yScale: "log",
        breakPoint: analyzed.breakPoint,
        showVoltage,
        showSmoothLine
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "flux-time", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      FluxTimeGraph,
      {
        fluxData: analyzed.fluxData,
        timeUnit,
        resistance,
        tau: analyzed.tau,
        hasRawSamples
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(TabsContent, { value: "flux-linear", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      FluxCurveGraph,
      {
        fluxData: analyzed.fluxData,
        currentUnit,
        resistance,
        scale: "linear",
        puData,
        tau: analyzed.tau,
        hasRawSamples
      }
    ) })
  ] });
}
function generateExponentialData(opts = {}) {
  const {
    samples = 100,
    tStart = -3,
    tEnd = 17,
    peak = 20,
    tauRise = 1.3,
    tauDecay = 3.5,
    addNoise = true,
    noiseStartTime = 12,
    noiseStrength = 0.2
  } = opts;
  const step = (tEnd - tStart) / (samples - 1);
  const points = [];
  for (let k = 0; k < samples; k++) {
    const t = tStart + k * step;
    let value;
    if (t < 0) {
      value = peak * Math.exp(t / tauRise);
    } else {
      value = peak * Math.exp(-t / tauDecay);
    }
    if (addNoise && t > noiseStartTime) {
      value += (Math.random() - 0.5) * value * noiseStrength;
    }
    points.push({
      timestamp: +(t * 1e3).toFixed(3),
      // seconds -> ms, to match RawPoint
      current: +value.toFixed(4),
      voltage: 0,
      phase: 0,
      new_timestamp: 0,
      linked_flux: 0
    });
  }
  return points;
}
function useDummySimulation() {
  const [active, setActive] = reactExports.useState(false);
  const [points, setPoints] = reactExports.useState([]);
  const [resistance, setResistance] = reactExports.useState(0.05);
  const [duration, setDuration] = reactExports.useState(0);
  const startedAtRef = reactExports.useRef(null);
  const start = () => {
    setPoints(generateExponentialData({ peak: 368.92 }));
    startedAtRef.current = Date.now();
    setDuration(0);
    setActive(true);
  };
  const stop = () => {
    if (startedAtRef.current) {
      setDuration((Date.now() - startedAtRef.current) / 1e3);
    }
    setActive(false);
  };
  reactExports.useEffect(() => {
    if (!active) return;
    const id = setInterval(() => {
      if (startedAtRef.current) {
        setDuration((Date.now() - startedAtRef.current) / 1e3);
      }
    }, 200);
    return () => clearInterval(id);
  }, [active]);
  const peak = points.length ? Math.max(...points.map((p) => p.current), 0) : 0;
  return { active, points, resistance, setResistance, duration, start, stop, peak };
}
const ABORT_REASON_LABEL = {
  ACB_TRIP: "ACB Trip",
  DC_TRIP: "DC Trip"
};
function Dashboard() {
  const [timeUnit, setTimeUnit] = reactExports.useState("MS");
  const [currentUnit, setCurrentUnit] = reactExports.useState("A");
  const [showVoltage, setShowVoltage] = reactExports.useState(false);
  const [showSmoothLine, setShowSmoothLine] = reactExports.useState(false);
  const [expand, setExpand] = reactExports.useState(false);
  const [justSaved, setJustSaved] = reactExports.useState(null);
  const {
    theme,
    toggle
  } = useTheme();
  const {
    objects,
    saveReport,
    getReport,
    getObject
  } = useTestObjects();
  const {
    settings
  } = useSettings();
  const isLive = settings.dataSource === "live";
  const [selectedId, setSelectedId] = reactExports.useState(null);
  const [setpointError, setSetpointError] = reactExports.useState(null);
  const [writeProgress, setWriteProgress] = reactExports.useState(null);
  const pollRef = reactExports.useRef(null);
  const startProgressPolling = () => {
    if (pollRef.current) return;
    pollRef.current = window.setInterval(() => {
      fetch("http://localhost:3000/api/prepare-test/status").then((res) => res.json()).then((p) => {
        setWriteProgress(p?.active ? p : null);
      }).catch(() => {
      });
    }, 250);
  };
  const stopProgressPolling = () => {
    if (pollRef.current) {
      window.clearInterval(pollRef.current);
      pollRef.current = null;
    }
    setWriteProgress(null);
  };
  reactExports.useEffect(() => () => stopProgressPolling(), []);
  const {
    raw,
    analysis,
    phase,
    connected: connected2,
    duration,
    latestCurrent,
    peakCurrent,
    interlock,
    abortReason,
    hardwareFault,
    reset
  } = useReactorTesting();
  const [abortReasonDismissed, setAbortReasonDismissed] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setAbortReasonDismissed(false);
  }, [abortReason]);
  const sim = useDummySimulation();
  reactExports.useEffect(() => {
    if (isLive && sim.active) {
      sim.stop();
    }
  }, [isLive]);
  const selectedObject = selectedId ? getObject(selectedId) : null;
  const hasExistingReport = selectedId ? !!getReport(selectedId) : false;
  const isRunning = phase === "ramp_up";
  const points = isRunning ? raw : analysis.length ? analysis : raw;
  const datasetLabel = isRunning ? "RAW · LIVE" : `ANALYSIS · ${analysis.length} pts`;
  const fmtCurrent = (v) => convertCurrentUnit(v, currentUnit).toFixed(currentUnit === "mA" ? 0 : 2);
  const doSave = (rawResult, analysisResult, peak, durationS) => {
    if (!selectedId) return;
    const obj = getObject(selectedId);
    let calculatedResults;
    if (obj && rawResult.length > 0) {
      const resAt20 = obj.resAt20DegC ?? 0;
      const {
        tau,
        breakPoint,
        fluxData
      } = createAnalyzedSample(rawResult, resAt20);
      const timeConstant = computeTimeConstant(obj.inductance ?? 0, resAt20);
      const timeToSteadyState = computeTimeToSteadyState(timeConstant);
      const ultimateDcVoltage = computeUltimateDcVoltage(obj.resIncreaseByLeadsPu ?? 0, obj.idcForLinearityTest ?? 0, obj.resAtRefTemp ?? 0);
      const magneticCharacteristic = computeMagneticCharacteristicPu(fluxData, obj.inductance ?? 0, obj.ratedAcRmsCurrent ?? 0);
      calculatedResults = {
        tau,
        timeConstant,
        timeToSteadyState,
        ultimateDcVoltage,
        breakPointCurrent: breakPoint?.current ?? null,
        breakPointTimeSec: breakPoint ? breakPoint.timestamp / 1e3 : null,
        magneticCharacteristic
      };
    }
    saveReport({
      objectId: selectedId,
      status: "passed",
      rawResult,
      analysisResult,
      calculatedResults,
      peakCurrent: peak,
      durationS,
      completedAt: Date.now()
    });
    setJustSaved(obj?.serialNumber ?? selectedId);
    window.setTimeout(() => setJustSaved(null), 4e3);
  };
  const prevPhaseRef = reactExports.useRef(phase);
  reactExports.useEffect(() => {
    const justCompleted = prevPhaseRef.current !== "completed" && phase === "completed";
    prevPhaseRef.current = phase;
    if (justCompleted && selectedId && raw.length > 0) {
      doSave(raw, analysis.length ? analysis : raw, peakCurrent, duration);
    }
  }, [phase, selectedId, raw.length]);
  const prevSimActiveRef = reactExports.useRef(sim.active);
  reactExports.useEffect(() => {
    const justStopped = prevSimActiveRef.current && !sim.active;
    prevSimActiveRef.current = sim.active;
    if (justStopped && selectedId && sim.points.length > 0) {
      doSave(sim.points, sim.points, sim.peak, sim.duration);
    }
  }, [sim.active, selectedId]);
  const handleSelectObject = (id) => {
    setSelectedId(id);
    if (id) {
      const obj = getObject(id);
      if (obj?.idcForLinearityTest) {
        startProgressPolling();
        fetch("http://localhost:3000/api/prepare-test", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            idc: obj.idcForLinearityTest
          })
        }).then((res) => res.json()).then((data) => {
          if (data.success) {
            setSetpointError(null);
            return;
          }
          const failedDefaults = [...data.currentMeterDefaults ?? [], ...data.voltageMeterDefaults ?? []].filter((r) => !r.success);
          const parts = [];
          if (failedDefaults.length > 0) {
            parts.push(`${failedDefaults.length} register(s) failed to reset: ` + failedDefaults.map((r) => `${r.name} (${r.error})`).join(", "));
          }
          if (data.idcSetpoint && !data.idcSetpoint.success) {
            parts.push(`Idc setpoint failed: ${data.idcSetpoint.error}`);
          }
          if (data.error) {
            parts.push(data.error);
          }
          setSetpointError(parts.join(" · ") || "Unknown error preparing the test bench.");
        }).catch((err) => {
          setSetpointError(`Could not reach test bench server: ${err.message}`);
        }).finally(() => {
          stopProgressPolling();
        });
      }
    } else {
      setSetpointError(null);
      stopProgressPolling();
    }
  };
  const showSim = !isLive && sim.active;
  const graphView = /* @__PURE__ */ jsxRuntimeExports.jsx(LinearityGraphTabs, { points: showSim ? sim.points : points, rawPoints: showSim ? sim.points : raw, timeUnit, currentUnit, peakCurrent: showSim ? sim.peak : peakCurrent, datasetLabel: showSim ? "SIMULATED · DUMMY DATA" : datasetLabel, resistance: showSim ? sim.resistance : selectedObject?.resAtRefTemp, inductance: selectedObject?.inductance ?? 4.49, ratedAcRmsCurrent: selectedObject?.ratedAcRmsCurrent ?? 171.8, showVoltage, showSmoothLine });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingScreen, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl space-y-6 px-4 py-8 lg:px-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BrandHeader, { theme, onToggleTheme: toggle }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel flex flex-wrap items-center justify-between gap-4 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground", children: "Active Test Object" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-sm font-semibold text-foreground", children: selectedObject ? `${selectedObject.serialNumber} · ${selectedObject.name}` : "None selected" }),
          selectedObject && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 font-mono text-[11px] text-muted-foreground", children: [
            selectedObject.idcForLinearityTest?.toFixed(2) ?? "—",
            " A target · ",
            selectedObject.maxVoltage,
            " V max",
            selectedObject.workOrder && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              " · WO ",
              selectedObject.workOrder
            ] }),
            hasExistingReport && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 rounded-sm border border-amber-500/40 bg-amber-500/10 px-1.5 py-0.5 text-amber-500", children: "report exists" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TestObjectSearch, { objects, selectedId, onSelect: handleSelectObject })
      ] }),
      justSaved && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-[var(--ok)]/40 bg-[var(--ok)]/10 px-4 py-2 font-mono text-xs text-[var(--ok)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Report saved for ",
          justSaved,
          "."
        ] })
      ] }),
      writeProgress?.active && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-border bg-card px-4 py-2 font-mono text-xs text-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 shrink-0 animate-spin text-amber-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Writing ",
          writeProgress.name,
          "... attempt ",
          writeProgress.attempt,
          " of ",
          writeProgress.maxRetries,
          writeProgress.maxRetries - writeProgress.attempt > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            " (",
            writeProgress.maxRetries - writeProgress.attempt,
            " retries left)"
          ] })
        ] })
      ] }),
      isLive && hardwareFault && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-4 py-2 font-mono text-xs text-destructive", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(PlugZap, { className: "h-4 w-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Hardware connection lost: ",
          hardwareFault,
          " — attempting to reconnect..."
        ] })
      ] }),
      abortReason && !abortReasonDismissed && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-2 font-mono text-xs text-amber-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Test aborted — ",
          ABORT_REASON_LABEL[abortReason] ?? abortReason
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setAbortReasonDismissed(true), className: "ml-auto shrink-0 text-[10px] font-bold uppercase tracking-wider text-amber-500/70 hover:text-amber-500", children: "Dismiss" })
      ] }),
      setpointError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-4 py-2 font-mono text-xs text-destructive", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: setpointError }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setSetpointError(null), className: "ml-auto shrink-0 text-[10px] font-bold uppercase tracking-wider text-destructive/70 hover:text-destructive", children: "Dismiss" })
      ] }),
      isRunning && !selectedId && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-2 font-mono text-xs text-amber-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4" }),
        "Bench test is running but no test object is selected — this run won't be saved to a report."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(InterlockStatusPanel, { status: interlock }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Live Current", value: fmtCurrent(latestCurrent), unit: currentUnitLabel(currentUnit), accent: "current" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Peak Current", value: fmtCurrent(peakCurrent), unit: currentUnitLabel(currentUnit), accent: "peak" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Test Duration", value: duration.toFixed(2), unit: "s", accent: "duration" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TestController, { status: phase, connected: isLive ? connected2 : true, timeUnit, currentUnit, onClear: reset, onTimeUnitChange: setTimeUnit, onCurrentUnitChange: setCurrentUnit, canArm: interlock.canArm, showVoltage, onShowVoltageChange: setShowVoltage, showSmoothLine, onShowSmoothLineChange: setShowSmoothLine }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 16
      }, animate: {
        opacity: 1,
        y: 0
      }, transition: {
        duration: 0.5,
        delay: 0.1
      }, className: "panel p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.2em] text-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Gauge, { className: "h-4 w-4 text-[var(--current)]" }),
            "Reactor Linearity Curve"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setExpand(true), className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 font-mono text-[11px] font-bold uppercase tracking-wider text-foreground transition hover:bg-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "h-3.5 w-3.5" }),
            " View"
          ] })
        ] }),
        graphView
      ] }),
      !isLive && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel flex flex-wrap items-center justify-between gap-4 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-mono text-[11px] text-muted-foreground", children: [
          "Dummy Mode · R (Ω):",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", step: "0.001", value: sim.resistance, onChange: (e) => sim.setResistance(parseFloat(e.target.value) || 0), className: "w-24 rounded-sm border border-border bg-card px-2 py-1 text-foreground" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: sim.active ? sim.stop : sim.start, className: "rounded-md bg-[var(--current)] px-4 py-2 font-mono text-xs font-bold uppercase tracking-widest text-background hover:brightness-110", children: sim.active ? "Stop Simulation (auto-saves)" : "Start Simulation" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-1 text-center font-mono text-[10px] tracking-[0.3em] text-muted-foreground", children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " ELECTROSOFT AUTOMATION · RLTS v2.2"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(GraphModal, { open: expand, onClose: () => setExpand(false), title: "Reactor Linearity Curve", children: graphView })
  ] });
}
export {
  Dashboard as component
};
