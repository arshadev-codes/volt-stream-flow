import { r as reactExports } from "../_libs/react.mjs";
import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import { g as getSettings } from "./settings-BuFBVS38.mjs";
const supabaseUrl = "https://gmsxpaqxrtwfbldxweyt.supabase.co";
const supabaseAnonKey = "sb_publishable_Xlbd2iYq3l1kPrWPqZKJ7w_0JY2R-G6";
const supabase = createClient(supabaseUrl, supabaseAnonKey);
const SUPABASE_URL = "https://gmsxpaqxrtwfbldxweyt.supabase.co";
const isApiEnabled = () => Boolean(SUPABASE_URL);
const TABLE = "test_objects";
const api = {
  listObjects: async () => {
    const { data, error } = await supabase.from(TABLE).select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
  /** Returns the existing row for this serial number, or null if free to use. */
  findBySerial: async (serialNumber) => {
    const { data, error } = await supabase.from(TABLE).select("id").eq("serial_number", serialNumber).maybeSingle();
    if (error) throw error;
    return data;
  },
  getObject: async (id) => {
    const { data, error } = await supabase.from(TABLE).select("*").eq("id", id).single();
    if (error) throw error;
    return data;
  },
  createObject: async (body) => {
    const { data, error } = await supabase.from(TABLE).insert(body).select().single();
    if (error) throw error;
    return data;
  },
  updateObject: async (id, body) => {
    const { data, error } = await supabase.from(TABLE).update(body).eq("id", id).select().single();
    if (error) throw error;
    return data;
  },
  deleteObject: async (id) => {
    const { error } = await supabase.from(TABLE).delete().eq("id", id);
    if (error) throw error;
    return { ok: true };
  },
  saveResults: async (id, body) => {
    const { data, error } = await supabase.from(TABLE).update(body).eq("id", id).select("id, modified_at").single();
    if (error) throw error;
    return { ok: true, ...data };
  }
};
const OBJ_KEY = "esa.testObjects.v2";
const REP_KEY = "esa.testReports.v2";
const listeners = /* @__PURE__ */ new Set();
const emit = () => listeners.forEach((l) => l());
let objCache = null;
let repCache = null;
function readLs(key, fallback) {
  if (typeof window === "undefined") return fallback;
  try {
    const r = localStorage.getItem(key);
    return r ? JSON.parse(r) : fallback;
  } catch {
    return fallback;
  }
}
function writeLs(key, value) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
  }
}
function safeJson(s) {
  try {
    return typeof s === "string" ? JSON.parse(s) : s;
  } catch {
    return null;
  }
}
function rowToObject(row) {
  const created = row.created_at ? new Date(row.created_at).getTime() : Date.now();
  const modified = row.modified_at ? new Date(row.modified_at).getTime() : row.completed_at ? new Date(row.completed_at).getTime() : created;
  return {
    id: String(row.id),
    serialNumber: row.serial_number,
    name: row.name ?? row.serial_number,
    manufacturer: row.manufacturer ?? void 0,
    projectName: row.project_name ?? "",
    customerName: row.customer_name ?? "",
    workOrder: row.work_order ?? "",
    ratedVoltage: Number(row.rated_voltage) || 0,
    maxVoltage: Number(row.max_voltage ?? row.rated_voltage) || 0,
    ratedCurrent: Number(row.rated_current) || 0,
    frequency: row.frequency ?? void 0,
    inductance: row.inductance ?? void 0,
    notes: row.notes ?? void 0,
    ratedPowerValue: row.rated_power_value ?? void 0,
    ratedPowerUnit: row.rated_power_unit ?? void 0,
    ratedPowerVA: row.rated_power_va ?? void 0,
    ratedVoltageNameplate: row.rated_voltage_nameplate ?? void 0,
    phases: row.phases ?? void 0,
    resAtRefTemp: row.res_at_ref_temp ?? void 0,
    refTempForRes: row.ref_temp_for_res ?? void 0,
    resIncreaseByLeadsPu: row.res_increase_by_leads_pu ?? void 0,
    ratedAcRmsCurrent: row.rated_ac_rms_current ?? void 0,
    resAt20DegC: row.res_at20_deg_c ?? void 0,
    idcForLinearityTest: row.idc_for_linearity_test ?? void 0,
    desiredTimeToReachIdc: row.desired_time_to_reach_idc ?? void 0,
    createdAt: created,
    modifiedAt: modified,
    status: row.status ?? "pending"
  };
}
function objectToRow(o) {
  return {
    serial_number: o.serialNumber,
    name: o.name,
    manufacturer: o.manufacturer,
    project_name: o.projectName,
    customer_name: o.customerName,
    work_order: o.workOrder,
    rated_voltage: o.ratedVoltage,
    max_voltage: o.maxVoltage,
    rated_current: o.ratedCurrent,
    frequency: o.frequency,
    inductance: o.inductance,
    notes: o.notes,
    rated_power_value: o.ratedPowerValue,
    rated_power_unit: o.ratedPowerUnit,
    rated_power_va: o.ratedPowerVA,
    rated_voltage_nameplate: o.ratedVoltageNameplate,
    phases: o.phases,
    res_at_ref_temp: o.resAtRefTemp,
    ref_temp_for_res: o.refTempForRes,
    res_increase_by_leads_pu: o.resIncreaseByLeadsPu,
    rated_ac_rms_current: o.ratedAcRmsCurrent,
    res_at20_deg_c: o.resAt20DegC,
    idc_for_linearity_test: o.idcForLinearityTest,
    desired_time_to_reach_idc: o.desiredTimeToReachIdc
  };
}
function listObjects() {
  if (objCache) return objCache;
  objCache = readLs(OBJ_KEY, []).sort((a, b) => b.createdAt - a.createdAt);
  if (isApiEnabled()) {
    api.listObjects().then((rows) => {
      objCache = rows.map(rowToObject).sort((a, b) => b.createdAt - a.createdAt);
      writeLs(OBJ_KEY, objCache);
      emit();
    }).catch(console.error);
  }
  return objCache;
}
function getObject(id) {
  return listObjects().find((o) => o.id === id);
}
async function createObject(input) {
  const serial = input.serialNumber.trim();
  const dupLocal = listObjects().find(
    (o) => o.serialNumber.trim().toLowerCase() === serial.toLowerCase()
  );
  if (dupLocal) {
    return { ok: false, error: `Serial number "${serial}" already exists.` };
  }
  const now = Date.now();
  const obj = { ...input, serialNumber: serial, id: crypto.randomUUID(), createdAt: now, modifiedAt: now, status: "pending" };
  if (isApiEnabled()) {
    try {
      const existing = await api.findBySerial(serial);
      if (existing) {
        return { ok: false, error: `Serial number "${serial}" already exists.` };
      }
      const row = await api.createObject({ ...objectToRow(obj), status: "pending" });
      obj.id = String(row.id);
    } catch (e) {
      const msg = String(e?.message ?? "");
      const isDuplicate = /duplicate|unique/i.test(msg);
      return {
        ok: false,
        error: isDuplicate ? `Serial number "${serial}" already exists.` : "Failed to save to the database. Check your connection and try again."
      };
    }
  }
  const all = [obj, ...listObjects()];
  objCache = all;
  writeLs(OBJ_KEY, all);
  emit();
  return { ok: true, object: obj };
}
async function updateObject(id, patch) {
  const existing = getObject(id);
  if (!existing) return { ok: false, error: "Test object not found." };
  const serial = patch.serialNumber.trim();
  const dupLocal = listObjects().find(
    (o) => o.id !== id && o.serialNumber.trim().toLowerCase() === serial.toLowerCase()
  );
  if (dupLocal) {
    return { ok: false, error: `Serial number "${serial}" already exists.` };
  }
  const updated = { ...existing, ...patch, serialNumber: serial, modifiedAt: Date.now() };
  if (isApiEnabled()) {
    try {
      const remoteDup = await api.findBySerial(serial);
      if (remoteDup && String(remoteDup.id) !== id) {
        return { ok: false, error: `Serial number "${serial}" already exists.` };
      }
      await api.updateObject(id, objectToRow(updated));
    } catch (e) {
      const msg = String(e?.message ?? "");
      const isDuplicate = /duplicate|unique/i.test(msg);
      return {
        ok: false,
        error: isDuplicate ? `Serial number "${serial}" already exists.` : "Failed to update the database. Check your connection and try again."
      };
    }
  }
  const all = listObjects().map((o) => o.id === id ? updated : o);
  objCache = all;
  writeLs(OBJ_KEY, all);
  emit();
  return { ok: true, object: updated };
}
function updateObjectStatus(id, status, modifiedAt) {
  const all = listObjects().map(
    (o) => o.id === id ? { ...o, status, modifiedAt: modifiedAt ?? o.modifiedAt } : o
  );
  objCache = all;
  writeLs(OBJ_KEY, all);
  emit();
  if (isApiEnabled()) {
    api.updateObject(id, {
      status,
      ...modifiedAt ? { completed_at: new Date(modifiedAt).toISOString() } : {}
    }).catch(console.error);
  }
}
function deleteObject(id) {
  objCache = listObjects().filter((o) => o.id !== id);
  repCache = listReports().filter((r) => r.objectId !== id);
  writeLs(OBJ_KEY, objCache);
  writeLs(REP_KEY, repCache);
  emit();
  if (isApiEnabled()) api.deleteObject(id).catch(console.error);
}
function listReports() {
  if (!repCache) repCache = readLs(REP_KEY, []);
  return repCache;
}
function getReport(objectId) {
  return listReports().find((r) => r.objectId === objectId);
}
function saveReport(report) {
  const storeRaw = getSettings().storeRawData;
  const persisted = storeRaw ? report : { ...report, rawResult: [] };
  const others = listReports().filter((r) => r.objectId !== persisted.objectId);
  repCache = [persisted, ...others];
  writeLs(REP_KEY, repCache);
  updateObjectStatus(persisted.objectId, persisted.status, persisted.completedAt);
  emit();
  if (isApiEnabled()) {
    api.updateObject(persisted.objectId, {
      status: persisted.status,
      peak_current: persisted.peakCurrent,
      duration_s: persisted.durationS,
      completed_at: new Date(persisted.completedAt).toISOString(),
      raw_result: storeRaw ? JSON.stringify(report.rawResult) : "[]",
      analysis_result: JSON.stringify(persisted.analysisResult),
      calculated_results: persisted.calculatedResults ? JSON.stringify(persisted.calculatedResults) : null
    }).catch(console.error);
  }
}
async function fetchReport(objectId) {
  const local = getReport(objectId);
  if (!isApiEnabled()) return local;
  try {
    const row = await api.getObject(objectId);
    if (!row) return local;
    const points = safeJson(row.analysis_result) ?? [];
    const raw = safeJson(row.raw_result) ?? [];
    const calculatedResults = safeJson(row.calculated_results) ?? local?.calculatedResults;
    const merged = {
      objectId,
      status: row.status ?? local?.status ?? "passed",
      rawResult: Array.isArray(raw) ? raw : [],
      analysisResult: Array.isArray(points) ? points : local?.analysisResult ?? [],
      calculatedResults,
      peakCurrent: Number(row.peak_current ?? local?.peakCurrent ?? 0),
      durationS: Number(row.duration_s ?? local?.durationS ?? 0),
      completedAt: row.completed_at ? new Date(row.completed_at).getTime() : Number(local?.completedAt ?? Date.now())
    };
    const others = listReports().filter((r) => r.objectId !== objectId);
    repCache = [merged, ...others];
    writeLs(REP_KEY, repCache);
    emit();
    return merged;
  } catch (e) {
    console.error(e);
    return local;
  }
}
function subscribe(listener) {
  listeners.add(listener);
  const onStorage = (e) => {
    if (e.key === OBJ_KEY || e.key === REP_KEY) {
      objCache = null;
      repCache = null;
      listener();
    }
  };
  if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
  };
}
function useTestObjects() {
  const [objects, setObjects] = reactExports.useState([]);
  const [reports, setReports] = reactExports.useState([]);
  const refresh = reactExports.useCallback(() => {
    setObjects(listObjects());
    setReports(listReports());
  }, []);
  reactExports.useEffect(() => {
    refresh();
    return subscribe(refresh);
  }, [refresh]);
  return {
    objects,
    reports,
    refresh,
    create: createObject,
    update: updateObject,
    remove: deleteObject,
    saveReport,
    getReport,
    fetchReport,
    getObject,
    updateStatus: updateObjectStatus
  };
}
const SQRT3 = Math.sqrt(3);
const SQRT2 = Math.sqrt(2);
const COPPER_K = 234.5;
const PU_LINEARITY = 1.5;
function powerUnitMultiplier(unit) {
  switch (unit) {
    case "VAR":
      return 1;
    case "KVAR":
      return 1e3;
    case "MVAR":
      return 1e6;
    default:
      return 1;
  }
}
function computeRatedVoltageV(value, unit) {
  const multiplier = unit === "MV" ? 1e6 : unit === "kV" ? 1e3 : 1;
  return value * multiplier;
}
function computeRatedPowerVA(value, unit) {
  if (!value || value <= 0) return 0;
  return value * powerUnitMultiplier(unit);
}
function computeRatedAcRmsCurrent(ratedPowerVA, ratedVoltageNameplate, phases) {
  if (!ratedPowerVA || !ratedVoltageNameplate) return 0;
  const denom = phases === 3 ? ratedVoltageNameplate * SQRT3 : ratedVoltageNameplate;
  return denom > 0 ? ratedPowerVA / denom : 0;
}
function computeResAt20DegC(resAtRefTemp, refTempForRes) {
  if (!resAtRefTemp || refTempForRes === void 0 || refTempForRes === null) return 0;
  const denom = COPPER_K + refTempForRes;
  return denom > 0 ? resAtRefTemp * (COPPER_K + 20) / denom : 0;
}
function computeIdcForLinearityTest(ratedAcRmsCurrent, multiplier = PU_LINEARITY) {
  if (!ratedAcRmsCurrent) return 0;
  return ratedAcRmsCurrent * multiplier * SQRT2;
}
function computeTimeConstant(inductance, resAt20DegC) {
  if (!inductance || !resAt20DegC) return 0;
  return inductance / resAt20DegC;
}
function computeTimeToSteadyState(timeConstant) {
  if (!timeConstant) return 0;
  return 5 * timeConstant;
}
function computeUltimateDcVoltage(resIncreaseByLeadsPu, idcForLinearityTest, resAtRefTemp) {
  if (!resIncreaseByLeadsPu || !idcForLinearityTest || !resAtRefTemp) return 0;
  return resIncreaseByLeadsPu * idcForLinearityTest * resAtRefTemp;
}
function computePeakDcPoint(points) {
  if (!points.length) return { timeSec: 0, voltage: 0 };
  let peak = points[0];
  for (const p of points) {
    if (p.current > peak.current) peak = p;
  }
  return { timeSec: peak.timestamp / 1e3, voltage: peak.voltage };
}
function computeVoltageAtTimestamp(points, timestampMs) {
  if (!points.length) return 0;
  let closest = points[0];
  let closestDiff = Math.abs(points[0].timestamp - timestampMs);
  for (const p of points) {
    const diff = Math.abs(p.timestamp - timestampMs);
    if (diff < closestDiff) {
      closest = p;
      closestDiff = diff;
    }
  }
  return closest.voltage;
}
function computeMagneticCharacteristicPu(fluxData, inductance, ratedAcRmsCurrent) {
  if (!inductance || !ratedAcRmsCurrent || fluxData.length < 2) return [];
  const iBase = ratedAcRmsCurrent * Math.SQRT2;
  const psiBase = inductance * iBase;
  if (iBase <= 0 || psiBase <= 0) return [];
  return fluxData.map((f) => ({
    CurrentPu: f.current / iBase,
    FluxPU: f.psi / psiBase
  }));
}
export {
  PU_LINEARITY as P,
  computeMagneticCharacteristicPu as a,
  computePeakDcPoint as b,
  computeIdcForLinearityTest as c,
  computeRatedAcRmsCurrent as d,
  computeRatedPowerVA as e,
  computeRatedVoltageV as f,
  computeResAt20DegC as g,
  computeTimeConstant as h,
  computeTimeToSteadyState as i,
  computeUltimateDcVoltage as j,
  computeVoltageAtTimestamp as k,
  useTestObjects as u
};
