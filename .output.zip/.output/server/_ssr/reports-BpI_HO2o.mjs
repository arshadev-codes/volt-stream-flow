import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { V as VoltageCurrentGraph, G as GraphModal, a as createAnalyzedSample } from "./VoltageCurrentGraph-BHuYz0x4.mjs";
import { p as pdf, S as StyleSheet } from "../_libs/react-pdf__renderer.mjs";
import { u as useTestObjects, h as computeTimeConstant, b as computePeakDcPoint, k as computeVoltageAtTimestamp, P as PU_LINEARITY, a as computeMagneticCharacteristicPu } from "./reactorCalcs-BDTazTR4.mjs";
import { Buffer } from "buffer";
import { g as gsapWithCSS } from "../_libs/gsap.mjs";
import { a as useTheme, B as BrandHeader } from "./settings-BuFBVS38.mjs";
import { m as motion, A as AnimatePresence } from "../_libs/framer-motion.mjs";
import { F as FileText, S as Search, b as CircleCheck, c as CircleX, a as Circle, L as LoaderCircle, d as Download, M as Maximize2 } from "../_libs/lucide-react.mjs";
import { d as Document, P as Page, V as View, T as Text, n as Svg, D as Defs, f as LinearGradient, m as Stop, l as Rect, L as Line, i as Path, b as Circle$1, I as Image } from "../_libs/react-pdf__primitives.mjs";
import "../_libs/recharts.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/es-toolkit.mjs";
import "../_libs/clsx.mjs";
import "../_libs/reselect.mjs";
import "../_libs/d3-shape.mjs";
import "../_libs/d3-path.mjs";
import "../_libs/reduxjs__toolkit.mjs";
import "../_libs/redux.mjs";
import "../_libs/immer.mjs";
import "../_libs/redux-thunk.mjs";
import "../_libs/react-redux.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/victory-vendor.mjs";
import "../_libs/d3-scale.mjs";
import "../_libs/internmap.mjs";
import "../_libs/d3-array.mjs";
import "../_libs/d3-time-format.mjs";
import "../_libs/d3-time.mjs";
import "../_libs/d3-interpolate.mjs";
import "../_libs/d3-color.mjs";
import "../_libs/d3-format.mjs";
import "../_libs/decimal.js-light.mjs";
import "../_libs/eventemitter3.mjs";
import "../_libs/react-pdf__font.mjs";
import "../_libs/is-url.mjs";
import "../_libs/fontkit.mjs";
import "../_libs/restructure.mjs";
import "fs";
import "../_libs/swc__helpers.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/unicode-properties.mjs";
import "../_libs/base64-js.mjs";
import "../_libs/unicode-trie.mjs";
import "../_libs/tiny-inflate.mjs";
import "../_libs/dfa.mjs";
import "../_libs/clone.mjs";
import "../_libs/brotli.mjs";
import "tslib";
import "../_libs/react-pdf__pdfkit.mjs";
import "zlib";
import "../_libs/js-md5.mjs";
import "../_libs/noble__ciphers.mjs";
import "events";
import "../_libs/linebreak.mjs";
import "../_libs/jay-peg.mjs";
import "../_libs/png-js.mjs";
import "../_libs/react-pdf__render.mjs";
import "../_libs/react-pdf__fns.mjs";
import "../_libs/abs-svg-path.mjs";
import "../_libs/parse-svg-path.mjs";
import "../_libs/normalize-svg-path.mjs";
import "../_libs/svg-arc-to-cubic-bezier.mjs";
import "../_libs/color-string.mjs";
import "../_libs/color-name.mjs";
import "../_libs/react-pdf__layout.mjs";
import "../_libs/react-pdf__stylesheet.mjs";
import "../_libs/media-engine.mjs";
import "../_libs/hsl-to-hex.mjs";
import "../_libs/hsl-to-rgb-for-reals.mjs";
import "../_libs/postcss-value-parser.mjs";
import "../_libs/react-pdf__textkit.mjs";
import "../_libs/bidi-js.mjs";
import "../_libs/hyphen.mjs";
import "../_libs/yoga-layout.mjs";
import "../_libs/emoji-regex-xs.mjs";
import "../_libs/react-pdf__image.mjs";
import "url";
import "path";
import "../_libs/react-pdf__svg.mjs";
import "../_libs/react-pdf__reconciler.mjs";
import "../_libs/scheduler.mjs";
import "../_libs/object-assign.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "./router-KWJ3Ta83.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const DEFAULT_REPORT_OPTIONS = {
  graphs: { rawWaveform: true, rawWaveformLog: true, fluxTime: true, fluxCurve: true },
  showBreakPoint: true,
  showSteadyState: true
};
async function exportReportPdf(object, report, signOff, options = DEFAULT_REPORT_OPTIONS) {
  const blob = await pdf(
    /* @__PURE__ */ jsxRuntimeExports.jsx(ReportDocument, { object, report, signOff, options })
  ).toBlob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Report_${object.serialNumber}_${report.status}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
if (typeof window !== "undefined" && !window.Buffer) {
  window.Buffer = Buffer;
}
const C = {
  accent: "#B45309",
  success: "#0F766E",
  danger: "#B91C1C",
  ink: "#0F172A",
  ink2: "#334155",
  // Previously lighter grey tones (#64748B / #94A3B8) read as "dull" in print.
  // Darkened to near-black so labels, footers, and secondary text stay crisp.
  mute: "#0F172A",
  muteLight: "#1E293B",
  line: "#94A3B8",
  lineStrong: "#475569",
  lineDark: "#1E293B",
  soft: "#F8FAFC",
  soft2: "#F1F5F9",
  white: "#FFFFFF",
  current: "#B45309",
  voltage: "#0369A1",
  breakDot: "#0F172A"
};
const PAGE_PAD = 40;
const FONT = "Helvetica";
const FONT_BOLD = "Helvetica-Bold";
const FONT_OBLIQUE = "Helvetica-Oblique";
const LOGO_SRC = "/logo-black.png";
const s = StyleSheet.create({
  page: {
    // Header shrunk from 44 -> 34 to match the footer's visual weight
    // (see s.headerBar / s.footer below); paddingTop trimmed to match,
    // keeping roughly the same ~14-16pt breathing room below the rule.
    paddingTop: 48,
    paddingBottom: 54,
    paddingHorizontal: PAGE_PAD,
    fontSize: 9.5,
    color: C.ink,
    fontFamily: FONT,
    backgroundColor: C.white
  },
  coverPage: {
    padding: 0,
    fontFamily: FONT,
    backgroundColor: C.white
  },
  headerBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 34,
    paddingHorizontal: PAGE_PAD,
    paddingTop: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    // 1px to match the footer's borderTopWidth exactly — was 1.2 (heavier
    // than the footer rule, which read as visually mismatched weight).
    borderBottomWidth: 1,
    borderBottomColor: C.lineDark
  },
  brand: { fontSize: 10, fontFamily: FONT_BOLD, color: C.ink, letterSpacing: 0.6 },
  brandSub: { fontSize: 6.3, fontFamily: FONT_BOLD, color: C.mute, letterSpacing: 1.6, marginTop: 1 },
  footer: {
    position: "absolute",
    left: PAGE_PAD,
    right: PAGE_PAD,
    bottom: 20,
    borderTopWidth: 1,
    borderTopColor: C.lineStrong,
    paddingTop: 7,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
  },
  footerLeft: { flexDirection: "row", alignItems: "center", gap: 5 },
  footerText: { color: C.mute, fontSize: 6.6 },
  eyebrow: { fontSize: 7.2, color: C.accent, fontFamily: FONT_BOLD, letterSpacing: 2.4 },
  title: { fontSize: 17, fontFamily: FONT_BOLD, color: C.ink },
  subtitle: { fontSize: 10.5, fontFamily: FONT_BOLD, color: C.ink2, marginTop: 1 },
  sectionTitle: {
    fontSize: 9.5,
    fontFamily: FONT_BOLD,
    color: C.ink,
    textTransform: "uppercase",
    letterSpacing: 1.4,
    marginTop: 20,
    marginBottom: 9,
    borderLeftWidth: 2.5,
    borderLeftColor: C.lineDark,
    paddingLeft: 8
  },
  sectionSub: { fontSize: 8, color: C.mute, marginTop: -6, marginBottom: 10, paddingLeft: 11 },
  row: { flexDirection: "row" },
  hero: {
    borderWidth: 1.2,
    borderColor: C.lineDark,
    backgroundColor: C.soft,
    padding: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 14
  },
  metaLine: { fontSize: 12.5, color: C.mute, marginTop: 7.5 },
  metaStrong: { fontFamily: FONT_BOLD, color: C.ink2 },
  badgePill: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1.2,
    marginBottom: 6
  },
  badgeDot: { width: 5, height: 5, marginRight: 5 },
  badgePillText: { fontSize: 7.6, fontFamily: FONT_BOLD, letterSpacing: 0.8 },
  kpiGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 4 },
  kpiCard: {
    width: "31.8%",
    borderWidth: 1.5,
    borderColor: C.lineDark,
    borderTopWidth: 2.5,
    backgroundColor: C.white,
    paddingVertical: 10,
    paddingHorizontal: 11,
    marginBottom: 8
  },
  kpiLabel: {
    fontSize: 6.6,
    fontFamily: FONT_BOLD,
    color: C.mute,
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: 5
  },
  kpiValueRow: { flexDirection: "row", alignItems: "flex-end" },
  kpiValue: { fontSize: 19, fontFamily: FONT_BOLD, color: C.ink },
  kpiUnit: { fontSize: 8, fontFamily: FONT_BOLD, color: C.mute, marginLeft: 3, marginBottom: 2 },
  card: { borderWidth: 1.2, borderColor: C.lineDark, backgroundColor: C.white },
  cardPad: { padding: 12 },
  dataRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 11,
    borderBottomWidth: 0.75,
    borderBottomColor: C.lineStrong
  },
  dataRowLast: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 11
  },
  dataRowZebra: { backgroundColor: C.soft },
  dataLabel: { flex: 1.35, fontSize: 8.4, color: C.mute },
  dataValueWrap: { flex: 1, flexDirection: "row", justifyContent: "flex-end", alignItems: "center" },
  dataValue: { fontSize: 9, fontFamily: FONT_BOLD, color: C.ink, textAlign: "right" },
  legendRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  conclusionBox: {
    borderWidth: 1.2,
    borderColor: C.lineDark,
    borderLeftWidth: 3,
    padding: 13,
    backgroundColor: C.soft
  },
  conclusionText: { fontSize: 12, color: C.ink2, lineHeight: 1.55 },
  statCard: {
    flex: 1,
    borderWidth: 1.2,
    borderColor: C.lineDark,
    backgroundColor: C.white,
    paddingVertical: 8,
    paddingHorizontal: 10
  },
  statLabel: { fontSize: 6.4, fontFamily: FONT_BOLD, color: C.mute, textTransform: "uppercase", letterSpacing: 1, marginBottom: 3 },
  statValue: { fontSize: 13, fontFamily: FONT_BOLD, color: C.ink },
  signBox: {
    flex: 1,
    borderWidth: 1.2,
    borderColor: C.lineDark,
    padding: 12,
    minHeight: 115
  },
  signRole: { fontSize: 7.4, fontFamily: FONT_BOLD, color: C.ink2, textTransform: "uppercase", letterSpacing: 1.2, marginBottom: 6 },
  signLine: { borderBottomWidth: 1, borderBottomColor: C.lineDark, marginBottom: 4 },
  signMeta: { fontSize: 6.6, color: C.muteLight, textTransform: "uppercase", letterSpacing: 0.8 },
  /* Cover-page info table — a bigger, bolder tabular block for the
     Serial Number / Work Order / Reactor Name / etc. group, distinct
     from the compact DataCard used elsewhere in the report. */
  coverInfoCard: {
    borderWidth: 1.4,
    borderColor: C.lineDark,
    backgroundColor: C.white
  },
  coverInfoRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderBottomWidth: 0.75,
    borderBottomColor: C.lineStrong
  },
  coverInfoRowLast: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 9,
    paddingHorizontal: 14
  },
  coverInfoRowZebra: { backgroundColor: C.soft },
  coverInfoLabel: {
    flex: 1,
    fontSize: 9,
    fontFamily: FONT_BOLD,
    color: C.mute,
    textTransform: "uppercase",
    letterSpacing: 0.8
  },
  coverInfoValue: { flex: 1.3, fontSize: 11.5, fontFamily: FONT_BOLD, color: C.ink, textAlign: "right" }
});
function fmt(n, decimals = 3) {
  if (n === void 0 || n === null || Number.isNaN(n) || n === 0) return "—";
  return n.toFixed(decimals);
}
function fmtInt(n) {
  if (n === void 0 || n === null || Number.isNaN(n)) return "—";
  return String(n);
}
function fmtEngineering(n, unit, decimals = 2) {
  if (n === void 0 || n === null || Number.isNaN(n) || n === 0) return "—";
  const abs = Math.abs(n);
  if (abs >= 1e6) return `${(n / 1e6).toFixed(decimals)} M${unit}`;
  if (abs >= 1e3) return `${(n / 1e3).toFixed(decimals)} k${unit}`;
  return `${n.toFixed(decimals)} ${unit}`;
}
const UNIT_SYMBOLS = {
  C: "°C"
  // °C
};
function unitSymbol(unit) {
  return UNIT_SYMBOLS[unit] ?? unit;
}
function fmtWithUnit(n, unit, decimals = 3) {
  const num = fmt(n, decimals);
  if (num === "—") return num;
  return `${num} ${unitSymbol(unit)}`;
}
function formatNum(n) {
  return n.toLocaleString();
}
function Idc({ fontSize }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "I",
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: fontSize * 0.62 }, children: "dc" })
  ] });
}
function DataRow({ row, index, last }) {
  const zebra = index % 2 === 1 ? s.dataRowZebra : {};
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [last ? s.dataRowLast : s.dataRow, zebra], children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.dataLabel, children: row.label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: s.dataValueWrap, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.dataValue, children: row.value }) })
  ] });
}
function DataCard({ rows }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: s.card, children: rows.map((r, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(DataRow, { row: r, index: i, last: i === rows.length - 1 }, i)) });
}
function CoverInfoRow({ row, index, last }) {
  const zebra = index % 2 === 1 ? s.coverInfoRowZebra : {};
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [last ? s.coverInfoRowLast : s.coverInfoRow, zebra], children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.coverInfoLabel, children: row.label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.coverInfoValue, children: row.value })
  ] });
}
function CoverInfoCard({ rows }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: s.coverInfoCard, children: rows.map((r, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CoverInfoRow, { row: r, index: i, last: i === rows.length - 1 }, i)) });
}
function SectionTitle({ children, sub }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.sectionTitle, children }),
    sub && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.sectionSub, children: sub })
  ] });
}
function KpiCard({ label, value, unit, accent, style }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [s.kpiCard, { borderTopColor: accent }, style], children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.kpiLabel, children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: s.kpiValueRow, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.kpiValue, children: value }),
      unit && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.kpiUnit, children: unit })
    ] })
  ] });
}
function Logo({ width = 20, height = 10 }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { src: LOGO_SRC, style: { width, height, objectFit: "contain" } });
}
function computeReportFields(object, report) {
  const timeConstant = computeTimeConstant(object.inductance ?? 0, object.resAt20DegC ?? 0);
  const testPoints = report.analysisResult.length ? report.analysisResult : report.rawResult;
  const peakDc = computePeakDcPoint(testPoints);
  const analyzed = createAnalyzedSample(testPoints, object.resAtRefTemp ?? object.resAt20DegC ?? 0);
  const breakPoint = analyzed.breakPoint;
  const timeToSteadyState = breakPoint ? breakPoint.timestamp / 1e3 : 0;
  const ultimateDcVoltage = breakPoint ? computeVoltageAtTimestamp(testPoints, breakPoint.timestamp) : 0;
  return { timeConstant, timeToSteadyState, ultimateDcVoltage, peakDc };
}
function computeDecayDuration(report, calc) {
  return Math.max(report.durationS - calc.peakDc.timeSec, 0);
}
function findCurrentAtTimestamp(points, timestampMs) {
  if (!points.length) return null;
  if (timestampMs <= points[0].timestamp) return points[0].current;
  for (let i = 1; i < points.length; i++) {
    if (points[i].timestamp >= timestampMs) {
      const p0 = points[i - 1];
      const p1 = points[i];
      const span = p1.timestamp - p0.timestamp || 1;
      const frac = (timestampMs - p0.timestamp) / span;
      return p0.current + (p1.current - p0.current) * frac;
    }
  }
  return points[points.length - 1].current;
}
function buildConclusion(object, report, calc) {
  const passed = report.status === "passed";
  const idc = object.idcForLinearityTest ?? 0;
  const pctOfIdc = idc > 0 ? report.peakCurrent / idc * 100 : 0;
  if (passed) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      `The unit under test achieved a peak current of ${report.peakCurrent.toFixed(2)} A, ${pctOfIdc ? pctOfIdc.toFixed(1) : "—"}% of the computed `,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 12 }),
      ` target of ${fmt(idc, 2)} A (PU Linearity ${object.puLinearity ?? PU_LINEARITY}× rated current). The recorded curve reached its peak at ${calc.peakDc.timeSec.toFixed(2)} sec with an applied DC voltage of ${calc.peakDc.voltage.toFixed(1)} V, against a computed time constant (tau) of ${calc.timeConstant.toFixed(3)} sec and an ultimate DC voltage of ${fmt(calc.ultimateDcVoltage, 1)} V. Based on these results, ${object.serialNumber} is assessed as PASSED for linearity per IEC 60076-6.`
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    `The unit under test recorded a peak current of ${report.peakCurrent.toFixed(2)} A against a computed `,
    /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 12 }),
    ` target of ${fmt(idc, 2)} A. This test run has been marked FAILED. Review the recorded current-rise curve against the computed reference parameters (tau = ${calc.timeConstant.toFixed(3)} sec, ultimate DC voltage = ${fmt(calc.ultimateDcVoltage, 1)} V) before scheduling a re-test.`
  ] });
}
function buildNameplateRows(object, calc) {
  const unitLabel = object.ratedPowerUnit === "MVAR" ? "MVAr" : object.ratedPowerUnit ?? "";
  return [
    { label: "Serial Number", value: object.serialNumber || "—" },
    { label: "Work Order", value: object.workOrder || "—" },
    {
      label: "Rated Power",
      value: object.ratedPowerValue ? `${fmt(object.ratedPowerValue, 2)} ${unitLabel}` : "—"
    },
    { label: "Rated Voltage (Nameplate)", value: fmtEngineering(object.ratedVoltageNameplate, "V") },
    { label: "No. of Phases", value: fmtInt(object.phases) },
    { label: "Frequency", value: fmtWithUnit(object.frequency, "Hz", 1) },
    { label: "Rated AC RMS Current", value: fmtWithUnit(object.ratedAcRmsCurrent, "A") },
    { label: "Inductance", value: fmtWithUnit(object.inductance, "H", 4) },
    { label: "Resistance/Phase at Ref Temp", value: fmtWithUnit(object.resAtRefTemp, "Ohm") },
    { label: "Reference Temp for Resistance", value: fmtWithUnit(object.refTempForRes, "C", 1) },
    { label: "Resistance/Phase at 20C", value: fmtWithUnit(object.resAt20DegC, "Ohm") },
    { label: "Resistance Increase by Leads", value: fmtWithUnit(object.resIncreaseByLeadsPu, "PU", 4) }
  ];
}
function CoverPage({
  object,
  report,
  calc,
  conclusion,
  generated,
  completed,
  hasRaw,
  signOff
}) {
  const passed = report.status === "passed";
  const statusColor = passed ? C.success : C.danger;
  const infoRows = [
    { label: "Serial Number", value: object.serialNumber || "—" },
    { label: "Work Order", value: object.workOrder || "—" },
    { label: "Reactor Name", value: object.name || "Reactor Unit" },
    { label: "Project", value: object.projectName || "—" },
    { label: "Customer", value: object.customerName || "—" },
    { label: "Test Engineer", value: signOff.testedBy.name || "—" },
    { label: "Test Date", value: completed },
    { label: "Report Generated", value: generated }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Page, { size: "A4", style: s.coverPage, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { height: 3, backgroundColor: C.accent } }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: { paddingHorizontal: 44, paddingTop: 40, paddingBottom: 26, borderBottomWidth: 1.2, borderBottomColor: C.lineDark }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { marginBottom: 14 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Logo, { width: 150, height: 72 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 19, fontFamily: FONT_BOLD, color: C.ink, letterSpacing: 0.6, marginBottom: 14 }, children: "ATLANTA ELECTRONICS" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { marginBottom: 16 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(CoverInfoCard, { rows: infoRows }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { color: C.accent, fontSize: 14, fontFamily: FONT_BOLD, letterSpacing: 2, marginBottom: 4, marginTop: 10 }, children: "REACTOR LINEARITY TEST REPORT" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: { paddingHorizontal: 44, paddingTop: 24, flex: 1 }, children: [
      object.notes && /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: { marginBottom: 20 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 7.2, fontFamily: FONT_BOLD, color: C.mute, letterSpacing: 1.6, marginBottom: 8 }, children: "NOTES" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: [s.card, s.cardPad], children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 9, color: C.ink2, lineHeight: 1.5 }, children: object.notes }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 12, fontFamily: FONT_BOLD, color: C.mute, letterSpacing: 1.6, marginBottom: 8 }, children: "TEST OVERVIEW" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: [s.conclusionBox, { borderLeftColor: statusColor }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.conclusionText, children: conclusion }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: { borderTopWidth: 1.2, borderTopColor: C.lineDark, paddingHorizontal: 44, paddingVertical: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 6.6, color: C.mute, opacity: 0.6 }, children: "System generated report using ReactorX by Electrosoft Automation Pvt.Ltd." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Text, { style: { fontSize: 7.3, color: C.mute }, children: [
        "Generated ",
        generated,
        " · ID ",
        object.id.slice(0, 8).toUpperCase()
      ] })
    ] })
  ] });
}
function KeyMetricsAndNameplatePage({
  object,
  report,
  calc,
  generated,
  npLeft,
  npRight
}) {
  const decayDuration = computeDecayDuration(report, calc);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Page, { size: "A4", style: s.page, wrap: true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, { generated, object }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "Reactor Technical Specification & Linearity Data" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [s.row, { gap: 10 }], wrap: false, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(DataCard, { rows: npLeft }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(DataCard, { rows: npRight }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "Key Metrics" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: s.kpiGrid, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Actual ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 6.6 })
      ] }), value: report.peakCurrent.toFixed(2), unit: "A", accent: C.accent }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Target ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 6.6 })
      ] }), value: fmt(object.idcForLinearityTest, 2), unit: "A", accent: C.accent }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "Total Test Duration", value: report.durationS.toFixed(2), unit: "s", accent: C.accent }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Time to Reach Actual",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 6.6 })
      ] }), value: calc.peakDc.timeSec.toFixed(2), unit: "s", accent: C.ink2 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "DC Voltage at Peak",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Idc, { fontSize: 6.6 })
      ] }), value: calc.peakDc.voltage.toFixed(1), unit: "V", accent: C.ink2 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "Decay Duration", value: decayDuration.toFixed(2), unit: "s", accent: C.ink2 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "Time Constant (tau)", value: calc.timeConstant.toFixed(3), unit: "s", accent: C.ink2 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "Time to Steady State", value: calc.timeToSteadyState.toFixed(2), unit: "s", accent: C.ink2 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "Ultimate DC Voltage at TAU", value: fmt(calc.ultimateDcVoltage, 1), unit: "V", accent: C.ink2 })
    ] })
  ] });
}
function ReportDocument({
  object,
  report,
  signOff,
  options
}) {
  const generated = (/* @__PURE__ */ new Date()).toLocaleString();
  const completed = new Date(report.completedAt).toLocaleString();
  const hasRaw = report.rawResult.length > 0;
  const graphPoints = report.analysisResult.length ? report.analysisResult : report.rawResult;
  const calc = computeReportFields(object, report);
  const conclusion = buildConclusion(object, report, calc);
  const steadyStateTimestampMs = calc.timeToSteadyState * 1e3;
  const steadyStateCurrent = calc.timeToSteadyState > 0 ? findCurrentAtTimestamp(graphPoints, steadyStateTimestampMs) : null;
  computeDecayDuration(report, calc);
  const npRows = buildNameplateRows(object);
  const npHalf = Math.ceil(npRows.length / 2);
  const npLeft = npRows.slice(0, npHalf);
  const npRight = npRows.slice(npHalf);
  while (npRight.length < npLeft.length) {
    npRight.push({ label: "", value: "" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Document, { title: `Reactor Test Report - ${object.serialNumber}`, author: "Electrosoft Automation", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      CoverPage,
      {
        object,
        report,
        calc,
        conclusion,
        generated,
        completed,
        hasRaw,
        signOff
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      KeyMetricsAndNameplatePage,
      {
        object,
        report,
        calc,
        generated,
        npLeft,
        npRight
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Page, { size: "A4", style: s.page, wrap: true, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, { generated, object }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "Recorded Linearity Curves" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        StackedGraphs,
        {
          points: graphPoints,
          peak: report.peakCurrent,
          resistance: object.resAtRefTemp ?? object.resAt20DegC,
          inductance: object.inductance,
          ratedAcRmsCurrent: object.ratedAcRmsCurrent,
          options,
          steadyStateCurrent
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "Approval & Sign-Off" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [s.row, { gap: 10 }], wrap: false, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SignOffBlock, { role: "Tested By", info: signOff.testedBy }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SignOffBlock, { role: "Verified By", info: signOff.verifiedBy }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SignOffBlock, { role: "Approved By", info: signOff.approvedBy })
      ] })
    ] }),
    hasRaw && /* @__PURE__ */ jsxRuntimeExports.jsxs(Page, { size: "A4", style: s.page, wrap: true, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, { generated, object }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "Raw Acquisition Data" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Text, { style: { fontSize: 8, color: C.mute, marginTop: -6, marginBottom: 10 }, children: [
        formatNum(report.rawResult.length),
        " samples recorded · downsampled for plot below."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        ChartCard,
        {
          points: report.rawResult,
          peak: report.peakCurrent,
          height: 250,
          scale: "linear"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionTitle, { children: [
        "Analysis Sample (first 30 of ",
        report.analysisResult.length,
        ")"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SampleTable, { points: report.analysisResult.slice(0, 30) })
    ] })
  ] });
}
function Header() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: s.headerBar, fixed: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(View, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.brand, children: "REACTOR LINEARITY TEST REPORT" }) }) });
}
function Footer({ generated, object }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: s.footer, fixed: true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.footerText, children: "System generated report using ReactorX by Electrosoft Automation Pvt.Ltd." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.footerText, render: ({ pageNumber, totalPages }) => `Page ${pageNumber} / ${totalPages}` })
  ] });
}
function SignOffBlock({ role, info }) {
  const hasDesignation = !!info.designation && info.designation.trim().length > 0;
  const hasName = !!info.name && info.name.trim().length > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: s.signBox, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.signRole, children: role }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Text, { style: { fontSize: 8.2, color: C.ink2 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontFamily: FONT_BOLD, color: C.ink }, children: hasDesignation ? info.designation : "Designation" }),
      " : ",
      hasName ? info.name : ""
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: [s.signLine, { marginTop: 40, width: "80%" }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: s.signMeta, children: "Signature" })
  ] });
}
function SampleTable({ points }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: { borderWidth: 1.2, borderColor: C.lineDark, overflow: "hidden" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [s.row, { backgroundColor: C.soft2, paddingVertical: 7, paddingHorizontal: 10, borderBottomWidth: 1.2, borderBottomColor: C.lineDark }], children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontFamily: FONT_BOLD, color: C.ink2, fontSize: 7.3, letterSpacing: 0.5 }, children: "TIME (ms)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontFamily: FONT_BOLD, color: C.ink2, fontSize: 7.3, letterSpacing: 0.5 }, children: "VOLTAGE (V)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontFamily: FONT_BOLD, color: C.ink2, fontSize: 7.3, letterSpacing: 0.5 }, children: "CURRENT (A)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontFamily: FONT_BOLD, color: C.ink2, fontSize: 7.3, letterSpacing: 0.5 }, children: "PHASE (rad)" })
    ] }),
    points.map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      View,
      {
        style: [s.row, { paddingVertical: 4.8, paddingHorizontal: 10, backgroundColor: i % 2 ? C.soft : C.white }],
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontSize: 8, color: C.ink2 }, children: p.timestamp.toFixed(2) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontSize: 8, color: C.ink2 }, children: p.voltage.toFixed(2) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontSize: 8, color: C.ink2 }, children: p.current.toFixed(3) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { flex: 1, fontSize: 8, color: C.ink2 }, children: p.phase.toFixed(3) })
        ]
      },
      i
    ))
  ] });
}
const CHART_W = 515;
const PAD = { l: 48, r: 24, t: 13, b: 24 };
function downsampleRaw(points, target = 600) {
  if (points.length <= target) return points;
  const stride = Math.max(1, Math.ceil(points.length / target));
  const out = [];
  for (let i = 0; i < points.length; i += stride) out.push(points[i]);
  if (out[out.length - 1] !== points[points.length - 1]) out.push(points[points.length - 1]);
  return out;
}
function GraphCard({
  title,
  subtitle,
  children,
  accent = C.lineDark
}) {
  return (
    // Box shrunk (padding 12->9, marginBottom 14->9) — was leaving each
    // graph noticeably taller than it needed to be, which was both the
    // "unnecessarily big box" complaint and the reason 2-graph reports
    // pushed Approval & Sign-Off onto the next page. A colored top
    // border (matching each chart's line color) replaces the plain grey
    // one for a bit more visual polish.
    /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { style: [s.card, { padding: 9, marginBottom: 9, borderTopWidth: 2.5, borderTopColor: accent }], wrap: false, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 8, fontFamily: FONT_BOLD, color: C.ink, letterSpacing: 0.3, marginBottom: subtitle ? 2 : 6 }, children: title }),
      subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 6.6, color: C.mute, marginBottom: 6, fontFamily: FONT_OBLIQUE }, children: subtitle }),
      children
    ] })
  );
}
function ChartCard({
  points,
  peak,
  height = 220,
  scale = "linear",
  breakPoint,
  steadyStateCurrent
}) {
  const CHART_H = height;
  if (points.length < 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { height: CHART_H, justifyContent: "center", alignItems: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { color: C.mute, fontSize: 9 }, children: "No data captured yet." }) });
  }
  const slim = downsampleRaw(points, 600);
  const tMin = slim[0].timestamp || 0;
  const tMax = slim[slim.length - 1].timestamp || 1;
  const recordedMax = Math.max(...slim.map((p) => p.current), 0.01);
  const innerW = CHART_W - PAD.l - PAD.r;
  const innerH = CHART_H - PAD.t - PAD.b;
  const sx = (t) => PAD.l + (t - tMin) / (tMax - tMin || 1) * innerW;
  let syI;
  let yTicks;
  let iMax;
  if (scale === "log") {
    const floor = 1;
    iMax = Math.max(recordedMax, peak, floor) * 1.3;
    const logMax = Math.log10(iMax);
    const logMin = Math.log10(floor);
    syI = (i) => {
      const v = Math.max(i, floor);
      const frac = (Math.log10(v) - logMin) / (logMax - logMin || 1);
      return PAD.t + innerH - frac * innerH;
    };
    yTicks = [];
    let t = floor;
    while (t <= iMax) {
      yTicks.push(t);
      t *= 10;
    }
  } else {
    iMax = recordedMax * 1.15;
    syI = (i) => PAD.t + innerH - i / iMax * innerH;
    yTicks = Array.from({ length: 6 }, (_, i) => iMax * (5 - i) / 5);
  }
  const clampY = (v) => scale === "log" ? Math.max(v, 1) : v;
  const linePath = slim.map((p, i) => `${i === 0 ? "M" : "L"}${sx(p.timestamp).toFixed(1)},${syI(clampY(p.current)).toFixed(1)}`).join(" ");
  const areaPath = `M${sx(slim[0].timestamp).toFixed(1)},${(PAD.t + innerH).toFixed(1)} ` + slim.map((p) => `L${sx(p.timestamp).toFixed(1)},${syI(clampY(p.current)).toFixed(1)}`).join(" ") + ` L${sx(slim[slim.length - 1].timestamp).toFixed(1)},${(PAD.t + innerH).toFixed(1)} Z`;
  const xVals = Array.from({ length: 7 }, (_, i) => tMin + (tMax - tMin) * i / 6);
  const gradId = `fill-${scale}`;
  const breakVisible = !!breakPoint && breakPoint.timestamp >= tMin && breakPoint.timestamp <= tMax;
  const breakX = breakVisible ? sx(breakPoint.timestamp) : 0;
  const breakY = breakVisible ? syI(clampY(breakPoint.current)) : 0;
  const steadyVisible = steadyStateCurrent != null && Number.isFinite(steadyStateCurrent);
  const steadyYRaw = steadyVisible ? syI(clampY(steadyStateCurrent)) : 0;
  const steadyY = Math.min(Math.max(steadyYRaw, PAD.t), PAD.t + innerH);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Svg, { width: CHART_W, height: CHART_H, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Defs, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(LinearGradient, { id: gradId, x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "0", stopColor: C.current, stopOpacity: 0.3 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "1", stopColor: C.current, stopOpacity: 0.02 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Rect, { x: PAD.l, y: PAD.t, width: innerW, height: innerH, fill: C.soft, stroke: C.lineDark, strokeWidth: 0.9 }),
      yTicks.map((_, i) => {
        const y = PAD.t + innerH * i / (yTicks.length - 1 || 1);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: y, x2: PAD.l + innerW, y2: y, stroke: C.line, strokeWidth: 0.4, strokeDasharray: "2,2" }, `gy${i}`);
      }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: areaPath, fill: `url(#${gradId})` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: linePath, stroke: C.current, strokeWidth: 1.6, fill: "none" }),
      steadyVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(
        Line,
        {
          x1: PAD.l,
          y1: steadyY,
          x2: PAD.l + innerW,
          y2: steadyY,
          stroke: C.success,
          strokeWidth: 0.9,
          strokeDasharray: "4,2"
        }
      ),
      breakVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(Circle$1, { cx: breakX, cy: breakY, r: 2.6, fill: C.breakDot, stroke: C.white, strokeWidth: 0.8 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t + innerH, x2: PAD.l + innerW, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t, x2: PAD.l, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 })
    ] }),
    yTicks.map((v, i) => {
      const y = syI(v) - 3;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: 2, top: y + 8, fontSize: 6.2, color: C.current, width: PAD.l - 6, textAlign: "right" }, children: v >= 100 ? v.toFixed(0) : v.toFixed(scale === "log" ? 0 : 1) }, `yl${i}`);
    }),
    xVals.map((v, i) => {
      const raw = sx(v) - 16;
      const x = Math.max(PAD.l - 6, Math.min(raw, PAD.l + innerW - 26));
      const align = i === 0 ? "left" : i === xVals.length - 1 ? "right" : "center";
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: x, top: PAD.t + innerH + 14, fontSize: 6.2, color: C.mute, width: 32, textAlign: align }, children: v < 1e3 ? `${v.toFixed(0)}ms` : `${(v / 1e3).toFixed(1)}s` }, `xl${i}`);
    }),
    breakVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: breakX - 12, top: breakY - 12, fontSize: 6.2, color: C.ink, fontFamily: FONT_BOLD }, children: "Break" }),
    steadyVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(
      Text,
      {
        style: {
          position: "absolute",
          left: PAD.l + innerW - 70,
          top: steadyY - 8,
          width: 70,
          fontSize: 6.2,
          color: C.success,
          fontFamily: FONT_BOLD,
          textAlign: "right"
        },
        children: "Steady State"
      }
    )
  ] });
}
function FluxTimeChart({
  fluxData,
  height = 220
}) {
  const CHART_H = height;
  if (fluxData.length < 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { height: CHART_H, justifyContent: "center", alignItems: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { color: C.mute, fontSize: 9 }, children: "No data captured yet." }) });
  }
  const xVals = fluxData.map((p) => p.new_timestamp);
  const yVals = fluxData.map((p) => p.linked_flux);
  const xMin = Math.min(...xVals);
  const xMax = Math.max(...xVals) || 1;
  const yMax = Math.max(...yVals) * 1.1 || 1;
  const innerW = CHART_W - PAD.l - PAD.r;
  const innerH = CHART_H - PAD.t - PAD.b;
  const sx = (v) => PAD.l + (v - xMin) / (xMax - xMin || 1) * innerW;
  const sy = (v) => PAD.t + innerH - v / yMax * innerH;
  const path = fluxData.map((p, i) => `${i === 0 ? "M" : "L"}${sx(p.new_timestamp).toFixed(1)},${sy(p.linked_flux).toFixed(1)}`).join(" ");
  const areaPath = `M${sx(fluxData[0].new_timestamp).toFixed(1)},${(PAD.t + innerH).toFixed(1)} ` + fluxData.map((p) => `L${sx(p.new_timestamp).toFixed(1)},${sy(p.linked_flux).toFixed(1)}`).join(" ") + ` L${sx(fluxData[fluxData.length - 1].new_timestamp).toFixed(1)},${(PAD.t + innerH).toFixed(1)} Z`;
  const yTicks = Array.from({ length: 6 }, (_, i) => yMax * (5 - i) / 5);
  const xTicks = Array.from({ length: 7 }, (_, i) => xMin + (xMax - xMin) * i / 6);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Svg, { width: CHART_W, height: CHART_H, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Defs, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(LinearGradient, { id: "flux-fill-t", x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "0", stopColor: C.voltage, stopOpacity: 0.28 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "1", stopColor: C.voltage, stopOpacity: 0.02 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Rect, { x: PAD.l, y: PAD.t, width: innerW, height: innerH, fill: C.soft, stroke: C.lineDark, strokeWidth: 0.9 }),
      yTicks.map((_, i) => {
        const y = PAD.t + innerH * i / (yTicks.length - 1 || 1);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: y, x2: PAD.l + innerW, y2: y, stroke: C.line, strokeWidth: 0.4, strokeDasharray: "2,2" }, `gy${i}`);
      }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: areaPath, fill: "url(#flux-fill-t)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: path, stroke: C.voltage, strokeWidth: 1.6, fill: "none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t + innerH, x2: PAD.l + innerW, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t, x2: PAD.l, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 })
    ] }),
    yTicks.map((v, i) => {
      const y = PAD.t + innerH * i / (yTicks.length - 1 || 1) - 3;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: 2, top: y + 8, fontSize: 6.2, color: C.voltage, width: PAD.l - 6, textAlign: "right" }, children: v.toFixed(v >= 10 ? 0 : 2) }, `yl${i}`);
    }),
    xTicks.map((v, i) => {
      const raw = sx(v) - 16;
      const x = Math.max(PAD.l - 6, Math.min(raw, PAD.l + innerW - 26));
      const align = i === 0 ? "left" : i === xTicks.length - 1 ? "right" : "center";
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: x, top: PAD.t + innerH + 14, fontSize: 6.2, color: C.mute, width: 32, textAlign: align }, children: v < 1e3 ? `${v.toFixed(0)}ms` : `${(v / 1e3).toFixed(1)}s` }, `xl${i}`);
    })
  ] });
}
function FluxCurrentChart({
  puData,
  height = 220
}) {
  const CHART_H = height;
  if (puData.length < 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { height: CHART_H, justifyContent: "center", alignItems: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { color: C.mute, fontSize: 9 }, children: "No data captured yet." }) });
  }
  const xVals = puData.map((p) => p.CurrentPu);
  const yVals = puData.map((p) => p.FluxPU);
  const xMin = 0;
  const xMax = Math.max(...xVals) * 1.1 || 1;
  const yMax = Math.max(...yVals) * 1.1 || 1;
  const innerW = CHART_W - PAD.l - PAD.r;
  const innerH = CHART_H - PAD.t - PAD.b - 12;
  const sx = (v) => PAD.l + (v - xMin) / (xMax - xMin || 1) * innerW;
  const sy = (v) => PAD.t + innerH - v / yMax * innerH;
  const path = puData.map((p, i) => `${i === 0 ? "M" : "L"}${sx(p.CurrentPu).toFixed(1)},${sy(p.FluxPU).toFixed(1)}`).join(" ");
  const areaPath = `M${sx(puData[0].CurrentPu).toFixed(1)},${(PAD.t + innerH).toFixed(1)} ` + puData.map((p) => `L${sx(p.CurrentPu).toFixed(1)},${sy(p.FluxPU).toFixed(1)}`).join(" ") + ` L${sx(puData[puData.length - 1].CurrentPu).toFixed(1)},${(PAD.t + innerH).toFixed(1)} Z`;
  const yTicks = Array.from({ length: 6 }, (_, i) => yMax * (5 - i) / 5);
  const xTicks = Array.from({ length: 7 }, (_, i) => xMin + (xMax - xMin) * i / 6);
  const anchorPt = puData.reduce((max, p) => p.CurrentPu > max.CurrentPu ? p : max, puData[0]);
  const anchorX = sx(anchorPt.CurrentPu);
  const anchorY = sy(anchorPt.FluxPU);
  const DESIRED_OFFSET_X = 34;
  const DESIRED_OFFSET_Y = 22;
  const MIN_OFFSET = 6;
  const availableOffsetX = Math.max(anchorX - (PAD.l + 8), MIN_OFFSET);
  const availableOffsetY = Math.max(anchorY - (PAD.t + 16), MIN_OFFSET);
  const offsetX = Math.min(DESIRED_OFFSET_X, availableOffsetX);
  const offsetY = Math.min(DESIRED_OFFSET_Y, availableOffsetY);
  const arrowTailX = anchorX - offsetX;
  const arrowTailY = anchorY - offsetY;
  const dx = anchorX - arrowTailX;
  const dy = anchorY - arrowTailY;
  const len = Math.sqrt(dx * dx + dy * dy) || 1;
  const backX = -dx / len;
  const backY = -dy / len;
  const rotate = (vx, vy, deg) => {
    const a = deg * Math.PI / 180;
    return [vx * Math.cos(a) - vy * Math.sin(a), vx * Math.sin(a) + vy * Math.cos(a)];
  };
  const headLen = 5.5;
  const [t1x, t1y] = rotate(backX, backY, 24);
  const [t2x, t2y] = rotate(backX, backY, -24);
  const tick1 = `${(anchorX + t1x * headLen).toFixed(1)},${(anchorY + t1y * headLen).toFixed(1)}`;
  const tick2 = `${(anchorX + t2x * headLen).toFixed(1)},${(anchorY + t2y * headLen).toFixed(1)}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Svg, { width: CHART_W, height: CHART_H, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Defs, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(LinearGradient, { id: "flux-fill-i", x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "0", stopColor: C.voltage, stopOpacity: 0.28 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Stop, { offset: "1", stopColor: C.voltage, stopOpacity: 0.02 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Rect, { x: PAD.l, y: PAD.t, width: innerW, height: innerH, fill: C.soft, stroke: C.lineDark, strokeWidth: 0.9 }),
      yTicks.map((_, i) => {
        const y = PAD.t + innerH * i / (yTicks.length - 1 || 1);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: y, x2: PAD.l + innerW, y2: y, stroke: C.line, strokeWidth: 0.4, strokeDasharray: "2,2" }, `gy${i}`);
      }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: areaPath, fill: "url(#flux-fill-i)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Path, { d: path, stroke: C.voltage, strokeWidth: 1.6, fill: "none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: arrowTailX, y1: arrowTailY, x2: anchorX, y2: anchorY, stroke: C.ink, strokeWidth: 0.8 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Path,
        {
          d: `M${anchorX.toFixed(1)},${anchorY.toFixed(1)} L${tick1} M${anchorX.toFixed(1)},${anchorY.toFixed(1)} L${tick2}`,
          stroke: C.ink,
          strokeWidth: 0.8,
          fill: "none"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t + innerH, x2: PAD.l + innerW, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { x1: PAD.l, y1: PAD.t, x2: PAD.l, y2: PAD.t + innerH, stroke: C.lineDark, strokeWidth: 0.9 })
    ] }),
    yTicks.map((v, i) => {
      const y = PAD.t + innerH * i / (yTicks.length - 1 || 1) - 3;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: 2, top: y + 8, fontSize: 6.2, color: C.voltage, width: PAD.l - 6, textAlign: "right" }, children: v.toFixed(3) }, `yl${i}`);
    }),
    xTicks.map((v, i) => {
      const raw = sx(v) - 16;
      const x = Math.max(PAD.l - 6, Math.min(raw, PAD.l + innerW - 26));
      const align = i === 0 ? "left" : i === xTicks.length - 1 ? "right" : "center";
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { position: "absolute", left: x, top: PAD.t + innerH + 14, fontSize: 6.2, color: C.mute, width: 32, textAlign: align }, children: v.toFixed(2) }, `xl${i}`);
    }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Text,
      {
        style: {
          position: "absolute",
          left: arrowTailX - 4,
          top: arrowTailY - 10,
          fontSize: 8.5,
          fontFamily: FONT_OBLIQUE,
          color: C.ink
        },
        children: "t"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Text,
      {
        style: {
          position: "absolute",
          left: PAD.l,
          top: PAD.t + innerH + 24,
          width: innerW,
          textAlign: "center",
          fontSize: 6.4,
          color: C.mute,
          fontFamily: FONT_BOLD,
          letterSpacing: 0.6
        },
        children: "CURRENT (p.u.)"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Text,
      {
        style: {
          position: "absolute",
          left: PAD.l,
          top: PAD.t - 11,
          fontSize: 6.2,
          color: C.mute,
          fontFamily: FONT_BOLD,
          letterSpacing: 0.6
        },
        children: "LINKED FLUX (p.u.)"
      }
    )
  ] });
}
function StackedGraphs({
  points,
  peak,
  resistance,
  inductance,
  ratedAcRmsCurrent,
  options,
  steadyStateCurrent
}) {
  if (points.length < 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: { height: 220, justifyContent: "center", alignItems: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { color: C.mute, fontSize: 9 }, children: "No data captured yet." }) });
  }
  const { graphs, showBreakPoint, showSteadyState } = options;
  const noGraphsSelected = !graphs.rawWaveform && !graphs.rawWaveformLog && !graphs.fluxTime && !graphs.fluxCurve;
  if (noGraphsSelected) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(View, { style: [s.card, { padding: 14, marginBottom: 14 }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { style: { fontSize: 9, color: C.mute }, children: "No graphs were selected for this report." }) });
  }
  const analyzed = createAnalyzedSample(points, resistance ?? 0);
  const puData = computeMagneticCharacteristicPu(
    analyzed.fluxData,
    inductance ?? 0,
    ratedAcRmsCurrent ?? 0
  );
  const dischargeOnly = analyzed.rawDisplay.filter((p) => p.timestamp >= 0);
  const fluxUnavailable = !resistance || analyzed.fluxData.length < 2;
  const puUnavailable = !inductance || !ratedAcRmsCurrent || puData.length < 2;
  const breakPointForCharts = showBreakPoint ? analyzed.breakPoint : null;
  const steadyStateForCharts = showSteadyState ? steadyStateCurrent ?? null : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(View, { children: [
    graphs.rawWaveform && /* @__PURE__ */ jsxRuntimeExports.jsx(GraphCard, { title: " Graph Of the charge and discharge current", accent: C.current, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ChartCard,
      {
        points: analyzed.rawDisplay,
        peak,
        height: 195,
        scale: "linear",
        breakPoint: breakPointForCharts,
        steadyStateCurrent: steadyStateForCharts
      }
    ) }),
    graphs.rawWaveformLog && /* @__PURE__ */ jsxRuntimeExports.jsx(GraphCard, { title: "Graph Of the discharge current With logarithmic current scaling", accent: C.current, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ChartCard,
      {
        points: dischargeOnly,
        peak,
        height: 195,
        scale: "log",
        breakPoint: breakPointForCharts,
        steadyStateCurrent: steadyStateForCharts
      }
    ) }),
    graphs.fluxTime && /* @__PURE__ */ jsxRuntimeExports.jsx(
      GraphCard,
      {
        title: " Calculated linked flux during discharge period",
        accent: C.voltage,
        subtitle: fluxUnavailable ? "Resistance not set on this object, or tau never locked — flux curve is empty." : void 0,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(FluxTimeChart, { fluxData: analyzed.fluxData, height: 195 })
      }
    ),
    graphs.fluxCurve && /* @__PURE__ */ jsxRuntimeExports.jsx(
      GraphCard,
      {
        title: "Magnetic characteristic",
        accent: C.voltage,
        subtitle: puUnavailable ? "Inductance or rated AC RMS current not set on this object — per-unit curve is empty." : void 0,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(FluxCurrentChart, { puData, height: 210 })
      }
    )
  ] });
}
const TESTED_BY_DESIGNATION = "Test Engineer";
function ExportSignOffDialog({ object, report, open, onClose }) {
  const [testedByName, setTestedByName] = reactExports.useState("");
  const [verifiedByDesignation, setVerifiedByDesignation] = reactExports.useState("");
  const [verifiedByName, setVerifiedByName] = reactExports.useState("");
  const [approvedByDesignation, setApprovedByDesignation] = reactExports.useState("");
  const [approvedByName, setApprovedByName] = reactExports.useState("");
  const [includeRawWaveform, setIncludeRawWaveform] = reactExports.useState(
    DEFAULT_REPORT_OPTIONS.graphs.rawWaveform
  );
  const [includeRawWaveformLog, setIncludeRawWaveformLog] = reactExports.useState(
    DEFAULT_REPORT_OPTIONS.graphs.rawWaveformLog
  );
  const [includeFluxTime, setIncludeFluxTime] = reactExports.useState(
    DEFAULT_REPORT_OPTIONS.graphs.fluxTime
  );
  const [includeFluxCurve, setIncludeFluxCurve] = reactExports.useState(
    DEFAULT_REPORT_OPTIONS.graphs.fluxCurve
  );
  const [showBreakPoint, setShowBreakPoint] = reactExports.useState(DEFAULT_REPORT_OPTIONS.showBreakPoint);
  const [showSteadyState, setShowSteadyState] = reactExports.useState(DEFAULT_REPORT_OPTIONS.showSteadyState);
  const [error, setError] = reactExports.useState(null);
  const [exporting, setExporting] = reactExports.useState(false);
  if (!open) return null;
  const resetAndClose = () => {
    setError(null);
    onClose();
  };
  const handleExport = async () => {
    setError(null);
    const signOff = {
      testedBy: { designation: TESTED_BY_DESIGNATION, name: testedByName.trim() },
      verifiedBy: { designation: verifiedByDesignation.trim(), name: verifiedByName.trim() },
      approvedBy: { designation: approvedByDesignation.trim(), name: approvedByName.trim() }
    };
    const options = {
      graphs: {
        rawWaveform: includeRawWaveform,
        rawWaveformLog: includeRawWaveformLog,
        fluxTime: includeFluxTime,
        fluxCurve: includeFluxCurve
      },
      showBreakPoint,
      showSteadyState
    };
    try {
      setExporting(true);
      await exportReportPdf(object, report, signOff, options);
      resetAndClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to export PDF.");
    } finally {
      setExporting(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: styles.overlay, role: "dialog", "aria-modal": "true", "aria-label": "Export report options", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.modal, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { style: styles.title, children: "Export Report" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: styles.helpText, children: "Everything below is optional. Names and designations print in the Approval & Sign-Off section of the PDF, directly below the graphs — leave a name blank to print a blank line for a handwritten signature after printing." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { style: styles.fieldset, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { style: styles.legend, children: "Tested By" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.fieldRow, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Designation",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: TESTED_BY_DESIGNATION, disabled: true, style: { ...styles.input, ...styles.inputDisabled } })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Name",
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: testedByName,
              onChange: (e) => setTestedByName(e.target.value),
              placeholder: "Optional",
              style: styles.input
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { style: styles.fieldset, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { style: styles.legend, children: "Verified By" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.fieldRow, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Designation",
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: verifiedByDesignation,
              onChange: (e) => setVerifiedByDesignation(e.target.value),
              placeholder: "e.g. Quality Manager",
              style: styles.input
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Name",
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: verifiedByName,
              onChange: (e) => setVerifiedByName(e.target.value),
              placeholder: "Optional",
              style: styles.input
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { style: styles.fieldset, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { style: styles.legend, children: "Approved By" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.fieldRow, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Designation",
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: approvedByDesignation,
              onChange: (e) => setApprovedByDesignation(e.target.value),
              placeholder: "e.g. Engineering Head",
              style: styles.input
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.label, children: [
          "Name",
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: approvedByName,
              onChange: (e) => setApprovedByName(e.target.value),
              placeholder: "Optional",
              style: styles.input
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { style: styles.fieldset, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { style: styles.legend, children: "Graphs to Include" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.checkGrid, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: includeRawWaveform,
              onChange: (e) => setIncludeRawWaveform(e.target.checked)
            }
          ),
          "Charge & discharge current"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: includeRawWaveformLog,
              onChange: (e) => setIncludeRawWaveformLog(e.target.checked)
            }
          ),
          "Discharge current (log scale)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: includeFluxTime,
              onChange: (e) => setIncludeFluxTime(e.target.checked)
            }
          ),
          "Linked flux vs. time"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: includeFluxCurve,
              onChange: (e) => setIncludeFluxCurve(e.target.checked)
            }
          ),
          "Magnetic characteristic"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { style: styles.fieldset, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { style: styles.legend, children: "Markers" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.checkGrid, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: showBreakPoint,
              onChange: (e) => setShowBreakPoint(e.target.checked)
            }
          ),
          "Show Break point"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: styles.checkRow, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              style: styles.checkbox,
              checked: showSteadyState,
              onChange: (e) => setShowSteadyState(e.target.checked)
            }
          ),
          "Show Steady State line"
        ] })
      ] })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: styles.error, children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: styles.actions, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: resetAndClose, style: styles.secondaryBtn, disabled: exporting, children: "Cancel" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleExport, style: styles.primaryBtn, disabled: exporting, children: exporting ? "Exporting…" : "Export PDF" })
    ] })
  ] }) });
}
const styles = {
  overlay: {
    position: "fixed",
    inset: 0,
    backgroundColor: "rgba(15, 23, 42, 0.55)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1e3,
    padding: 16
  },
  modal: {
    width: 560,
    maxWidth: "94vw",
    maxHeight: "90vh",
    overflowY: "auto",
    backgroundColor: "#FFFFFF",
    borderRadius: 10,
    padding: "22px 24px",
    boxShadow: "0 20px 60px rgba(0,0,0,0.25)",
    fontFamily: "system-ui, sans-serif",
    boxSizing: "border-box"
  },
  title: { fontSize: 17, fontWeight: 700, color: "#0F172A", margin: "0 0 8px" },
  helpText: { fontSize: 12.5, color: "#475569", lineHeight: 1.5, margin: "0 0 18px" },
  fieldset: { border: "1px solid #E2E8F0", borderRadius: 8, padding: "12px 14px", margin: "0 0 14px" },
  legend: { fontSize: 12, fontWeight: 700, color: "#0F172A", padding: "0 6px" },
  fieldRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: 12,
    marginTop: 4
  },
  label: {
    flex: "1 1 200px",
    minWidth: 180,
    display: "flex",
    flexDirection: "column",
    fontSize: 11.5,
    color: "#334155",
    fontWeight: 600,
    gap: 4
  },
  input: {
    fontSize: 13,
    padding: "7px 9px",
    borderRadius: 6,
    border: "1px solid #CBD5E1",
    fontWeight: 400,
    color: "#0F172A",
    outline: "none",
    boxSizing: "border-box",
    width: "100%"
  },
  inputDisabled: { backgroundColor: "#F1F5F9", color: "#64748B" },
  checkGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    columnGap: 16,
    rowGap: 10,
    marginTop: 4
  },
  checkRow: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 12.5,
    color: "#334155",
    fontWeight: 500,
    cursor: "pointer"
  },
  checkbox: { width: 15, height: 15, cursor: "pointer", flexShrink: 0 },
  error: { fontSize: 12.5, color: "#B91C1C", margin: "4px 0 10px" },
  actions: { display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 6 },
  secondaryBtn: {
    padding: "9px 16px",
    borderRadius: 7,
    border: "1px solid #CBD5E1",
    backgroundColor: "#FFFFFF",
    color: "#334155",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer"
  },
  primaryBtn: {
    padding: "9px 16px",
    borderRadius: 7,
    border: "none",
    backgroundColor: "#B45309",
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer"
  }
};
const PAGE_LIMIT = 100;
function ReportsPage() {
  const {
    theme,
    toggle
  } = useTheme();
  const {
    objects,
    fetchReport
  } = useTestObjects();
  const [filter, setFilter] = reactExports.useState("all");
  const [q, setQ] = reactExports.useState("");
  const [sortBy, setSortBy] = reactExports.useState("modifiedAt");
  const [selectedId, setSelectedId] = reactExports.useState(null);
  const [showRaw, setShowRaw] = reactExports.useState(false);
  const [report, setReport] = reactExports.useState(null);
  const [loadingReport, setLoadingReport] = reactExports.useState(false);
  const list = reactExports.useMemo(() => {
    const s2 = q.trim().toLowerCase();
    return objects.filter((o) => {
      if (filter !== "all" && o.status !== filter) return false;
      if (s2 && !`${o.serialNumber} ${o.name} ${o.workOrder} ${o.customerName}`.toLowerCase().includes(s2)) return false;
      return true;
    }).sort((a, b) => sortBy === "modifiedAt" ? b.modifiedAt - a.modifiedAt : b.createdAt - a.createdAt).slice(0, PAGE_LIMIT);
  }, [objects, filter, q, sortBy]);
  const selected = selectedId ? objects.find((o) => o.id === selectedId) ?? null : null;
  reactExports.useEffect(() => {
    if (!selectedId || !selected || selected.status === "pending") {
      setReport(null);
      return;
    }
    let cancelled = false;
    setLoadingReport(true);
    fetchReport(selectedId).then((r) => {
      if (cancelled) return;
      setReport(r ?? null);
      setLoadingReport(false);
    });
    return () => {
      cancelled = true;
    };
  }, [selectedId, selected?.status, fetchReport]);
  const listScope = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (!listScope.current) return;
    const ctx = gsapWithCSS.context(() => {
      gsapWithCSS.utils.toArray("[data-report-card]").forEach((el, i) => {
        gsapWithCSS.fromTo(el, {
          autoAlpha: 0,
          y: 14
        }, {
          autoAlpha: 1,
          y: 0,
          duration: 0.45,
          delay: Math.min(i * 0.012, 0.25),
          ease: "power2.out",
          scrollTrigger: {
            trigger: el,
            start: "top 95%",
            toggleActions: "play none none none"
          }
        });
      });
    }, listScope);
    return () => ctx.revert();
  }, [list.length]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl space-y-6 px-4 py-8 lg:px-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(BrandHeader, { theme, onToggleTheme: toggle }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 10
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.4
    }, className: "grid gap-6 lg:grid-cols-[380px_1fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel flex flex-col p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 font-display text-sm font-bold uppercase tracking-[0.2em]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4 text-amber-500" }),
            " Reports"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rounded-sm border border-border bg-card px-2 py-0.5 font-mono text-[10px] text-muted-foreground", children: [
            list.length,
            objects.length > PAGE_LIMIT ? ` / ${objects.length}` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center gap-2 rounded-md border border-border bg-card px-2.5 py-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: q, onChange: (e) => setQ(e.target.value), placeholder: "Search serial, name, WO, customer", className: "w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex gap-1", children: ["all", "pending", "passed", "failed"].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setFilter(f), className: `flex-1 rounded-md border px-2 py-1.5 text-[10px] font-bold uppercase tracking-widest transition ${filter === f ? "border-amber-500 bg-amber-500/15 text-amber-500" : "border-border bg-card text-muted-foreground hover:text-foreground"}`, children: f }, f)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "Sort" }),
          [{
            k: "modifiedAt",
            label: "Modified"
          }, {
            k: "createdAt",
            label: "Created"
          }].map(({
            k,
            label
          }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: `inline-flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-md border px-2 py-1.5 text-[10px] font-bold uppercase tracking-widest transition ${sortBy === k ? "border-amber-500 bg-amber-500/15 text-amber-500" : "border-border bg-card text-muted-foreground hover:text-foreground"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: sortBy === k, onChange: () => setSortBy(k), className: "h-3 w-3", style: {
              accentColor: "var(--peak)"
            } }),
            label
          ] }, k))
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 px-1 pb-2 pt-1 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: [
          "Sorted by ",
          sortBy === "modifiedAt" ? "modified" : "created",
          " date · showing latest ",
          PAGE_LIMIT
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: listScope, className: "max-h-[62vh] space-y-1.5 overflow-auto pr-1", children: [
          list.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border border-dashed border-border p-4 text-center text-xs text-muted-foreground", children: "No test objects match." }),
          list.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { "data-report-card": true, onClick: () => {
            setSelectedId(o.id);
            setShowRaw(false);
          }, className: `flex w-full items-start justify-between gap-2 rounded-md border px-3 py-2.5 text-left transition will-change-transform ${selectedId === o.id ? "border-amber-500/60 bg-amber-500/10" : "border-border bg-card hover:bg-accent"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 truncate text-sm font-semibold text-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status: o.status }),
                " ",
                o.serialNumber
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-[11px] text-muted-foreground", children: o.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { title: "Modified", children: [
                  "M: ",
                  fmtDate(o.modifiedAt)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mx-1 opacity-50", children: "·" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { title: "Created", children: [
                  "C: ",
                  fmtDate(o.createdAt)
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 rounded-sm border border-border bg-card px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground", children: o.status })
          ] }, o.id))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "panel p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: !selected ? /* @__PURE__ */ jsxRuntimeExports.jsx(Empty, {}, "empty") : selected.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pending, { object: selected }, `p-${selected.id}`) : loadingReport || !report ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingReport, {}, `l-${selected.id}`) : /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
        opacity: 0,
        y: 14
      }, animate: {
        opacity: 1,
        y: 0
      }, exit: {
        opacity: 0,
        y: -8
      }, transition: {
        duration: 0.35
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ReportDetail, { object: selected, report, showRaw, onToggleRaw: setShowRaw }) }, `r-${selected.id}`) }) })
    ] })
  ] }) });
}
function fmtDate(ts) {
  return new Date(ts).toLocaleDateString(void 0, {
    year: "2-digit",
    month: "short",
    day: "2-digit"
  });
}
function StatusIcon({
  status
}) {
  if (status === "passed") return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5 text-[var(--ok)]" });
  if (status === "failed") return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-3.5 w-3.5 text-destructive" });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { className: "h-3.5 w-3.5 text-muted-foreground" });
}
function Empty() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
    opacity: 0
  }, animate: {
    opacity: 1
  }, exit: {
    opacity: 0
  }, className: "flex h-full min-h-[40vh] flex-col items-center justify-center text-center text-muted-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "mb-2 h-10 w-10 opacity-40" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm", children: "Select a test object to view its report." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 font-mono text-[10px] uppercase tracking-widest opacity-60", children: "Data is fetched on demand" })
  ] });
}
function Pending({
  object
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
    opacity: 0
  }, animate: {
    opacity: 1
  }, exit: {
    opacity: 0
  }, className: "flex h-full min-h-[40vh] flex-col items-center justify-center text-center text-muted-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { className: "mb-2 h-10 w-10 opacity-40" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: object.serialNumber }),
      " has not been tested yet."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs", children: "Go to Testing and run a test for this object." })
  ] });
}
function LoadingReport() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
    opacity: 0
  }, animate: {
    opacity: 1
  }, exit: {
    opacity: 0
  }, className: "flex h-full min-h-[40vh] flex-col items-center justify-center text-center text-muted-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mb-2 h-8 w-8 animate-spin text-amber-500" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-mono text-[11px] uppercase tracking-widest", children: "Fetching report data…" })
  ] });
}
function ReportDetail({
  object,
  report,
  showRaw,
  onToggleRaw
}) {
  const hasRaw = report.rawResult.length > 0;
  const points = showRaw && hasRaw ? report.rawResult : report.analysisResult?.length ? report.analysisResult : report.rawResult;
  const datasetLabel = showRaw && hasRaw ? `RAW · 0.25 MS · ${report.rawResult.length} pts` : `ANALYSIS · 1 MS · ${report.analysisResult.length} pts`;
  const [expand, setExpand] = reactExports.useState(false);
  const [exportOpen, setExportOpen] = reactExports.useState(false);
  const graphView = /* @__PURE__ */ jsxRuntimeExports.jsx(VoltageCurrentGraph, { points, timeUnit: "MS", currentUnit: "A", peakCurrent: report.peakCurrent, datasetLabel });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 8
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.4
    }, className: "flex flex-wrap items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground", children: "Test Object" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "font-display text-xl font-bold tracking-wide text-foreground", children: [
          object.serialNumber,
          " · ",
          object.name
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 font-mono text-[11px] text-muted-foreground", children: [
          "Modified ",
          new Date(report.completedAt).toLocaleString(),
          " · Created ",
          new Date(object.createdAt).toLocaleDateString(),
          object.workOrder ? ` · WO ${object.workOrder}` : "",
          object.customerName ? ` · ${object.customerName}` : ""
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-md border px-3 py-1.5 font-mono text-[11px] font-bold uppercase tracking-widest ${report.status === "passed" ? "border-[var(--ok)]/60 bg-[var(--ok)]/15 text-[var(--ok)]" : "border-destructive/60 bg-destructive/15 text-destructive"}`, children: report.status }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setExportOpen(true), className: "inline-flex items-center gap-1.5 rounded-md bg-amber-500 px-3 py-1.5 font-mono text-[11px] font-bold uppercase tracking-widest text-background hover:brightness-110", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-3.5 w-3.5" }),
          " Export PDF"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 8
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.4,
      delay: 0.05
    }, className: "grid grid-cols-2 gap-3 sm:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Mini, { label: "Peak", value: `${report.peakCurrent.toFixed(2)} A` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Mini, { label: "Duration", value: `${report.durationS.toFixed(2)} s` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Mini, { label: "Raw Samples", value: hasRaw ? String(report.rawResult.length) : "—" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Mini, { label: "Analysis Pts", value: String(report.analysisResult.length) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 12
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.45,
      delay: 0.1
    }, className: "rounded-md border border-border bg-card p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex flex-wrap items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground", children: "Recorded Linearity Curve" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: `inline-flex items-center gap-2 rounded-md border border-border bg-card px-2.5 py-1.5 font-mono text-[11px] font-bold uppercase tracking-wider text-foreground ${hasRaw ? "cursor-pointer hover:bg-accent" : "cursor-not-allowed opacity-50"}`, title: hasRaw ? "" : "Raw data not stored for this report", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: showRaw && hasRaw, disabled: !hasRaw, onChange: (e) => onToggleRaw(e.target.checked), className: "h-3.5 w-3.5", style: {
              accentColor: "var(--peak)"
            } }),
            "Show Raw Data"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setExpand(true), className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 font-mono text-[11px] font-bold uppercase tracking-wider text-foreground transition hover:bg-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "h-3.5 w-3.5" }),
            " View"
          ] })
        ] })
      ] }),
      graphView
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(GraphModal, { open: expand, onClose: () => setExpand(false), title: `${object.serialNumber} · Linearity Curve`, children: graphView }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ExportSignOffDialog, { object, report, open: exportOpen, onClose: () => setExportOpen(false) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.details, { initial: {
      opacity: 0
    }, animate: {
      opacity: 1
    }, transition: {
      delay: 0.15,
      duration: 0.4
    }, className: "rounded-md border border-border bg-card p-4 text-sm", open: true, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("summary", { className: "cursor-pointer font-semibold text-foreground", children: "Job & object details" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid grid-cols-2 gap-2 font-mono text-[12px] text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Project: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: object.projectName || "—" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Customer: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: object.customerName || "—" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Work Order: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: object.workOrder || "—" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Manufacturer: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: object.manufacturer || "—" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Frequency: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.frequency ?? "—",
            " Hz"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Rated V: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.ratedVoltage,
            " V"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Max V: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.maxVoltage,
            " V"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Rated I: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.ratedCurrent,
            " A"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Target Idc: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.idcForLinearityTest?.toFixed(2) ?? "—",
            " A"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Inductance: ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-foreground", children: [
            object.inductance ?? "—",
            " mH"
          ] })
        ] }),
        object.notes && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-2", children: [
          "Notes: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: object.notes })
        ] })
      ] })
    ] })
  ] });
}
function Mini({
  label,
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { whileHover: {
    y: -2
  }, className: "rounded-md border border-border bg-card p-3 transition hover:border-amber-500/40", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 font-mono text-lg font-bold tabular-nums text-foreground", children: value })
  ] });
}
export {
  ReportsPage as component
};
