import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { b as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, c as createFileRoute, l as lazyRouteComponent, d as useRouterState } from "../_libs/tanstack__react-router.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { g as gsapWithCSS, S as ScrollTrigger } from "../_libs/gsap.mjs";
import { X, g as Menu, A as Activity, B as Boxes, F as FileText, l as Settings } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const appCss = "/assets/styles-CBO9e5Cy.css";
const logo = "/assets/electrosoft-logo-BtOsNG6c.png";
const NAV = [
  { to: "/", label: "Testing", icon: Activity, description: "Live reactor test" },
  { to: "/setup", label: "Test Objects", icon: Boxes, description: "Create & manage units" },
  { to: "/reports", label: "Reports", icon: FileText, description: "Results & export" },
  { to: "/settings", label: "Settings", icon: Settings, description: "Preferences & data" }
];
function AppSidebar() {
  const [open, setOpen] = reactExports.useState(false);
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => setOpen((v) => !v),
        className: "fixed left-3 top-3 z-40 inline-flex h-10 w-10 items-center justify-center rounded-md border border-border bg-panel text-foreground shadow-sm lg:hidden",
        "aria-label": "Toggle navigation",
        children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" })
      }
    ),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-30 bg-black/50 backdrop-blur-sm lg:hidden", onClick: () => setOpen(false) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "aside",
      {
        className: `fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-border bg-panel transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 border-b border-border px-5 py-5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-md border border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "", className: "h-7 w-7 object-contain dark:invert" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-[10px] font-bold uppercase tracking-[0.32em] text-amber-500 dark:text-amber-400", children: "Electrosoft" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-sm font-semibold text-foreground", children: "Automation Suite" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex-1 space-y-1 px-3 py-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-2 pb-2 text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground", children: "Workspace" }),
            NAV.map(({ to, label, icon: Icon, description }) => {
              const active = pathname === to;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Link,
                {
                  to,
                  onClick: () => setOpen(false),
                  className: `group flex items-start gap-3 rounded-md px-3 py-2.5 transition ${active ? "bg-accent text-foreground shadow-inner" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `mt-0.5 h-4 w-4 ${active ? "text-amber-500 dark:text-amber-400" : ""}` }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-muted-foreground", children: description })
                    ] })
                  ]
                },
                to
              );
            })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border px-5 py-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: "RLTS v2.1" })
        ]
      }
    )
  ] });
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$4 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Electrosoft Automation — Reactor Linearity Testing System" },
      { name: "description", content: "Industrial reactor linearity testing dashboard by Electrosoft Automation — real-time excitation rise and exponential decay analysis." },
      { name: "author", content: "Electrosoft Automation" },
      { name: "theme-color", content: "#f59e0b" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-title", content: "Electrosoft RLTS" },
      { name: "mobile-web-app-capable", content: "yes" },
      { property: "og:title", content: "Electrosoft Automation — RLTS" },
      { property: "og:description", content: "Industrial reactor linearity testing dashboard with real-time excitation and decay curves." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "/electrosoft-logo.png" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Electrosoft Automation — RLTS" },
      { name: "twitter:description", content: "Industrial reactor linearity testing dashboard." },
      { name: "twitter:image", content: "/electrosoft-logo.png" }
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/png", href: "/electrosoft-logo.png" },
      { rel: "apple-touch-icon", href: "/electrosoft-logo.png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$4.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-screen w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(AppSidebar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) })
  ] }) });
}
const $$splitComponentImporter$3 = () => import("./setup-c7ej1EET.mjs");
const Route$3 = createFileRoute("/setup")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component"),
  head: () => ({
    meta: [{
      title: "Test Objects — Electrosoft Automation RLTS"
    }, {
      name: "description",
      content: "Create and manage reactor test objects."
    }]
  })
});
const $$splitComponentImporter$2 = () => import("./settings-BbYo3ZoJ.mjs");
const Route$2 = createFileRoute("/settings")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component"),
  head: () => ({
    meta: [{
      title: "Settings — Electrosoft Automation RLTS"
    }, {
      name: "description",
      content: "Configure data acquisition and storage preferences."
    }]
  })
});
const $$splitComponentImporter$1 = () => import("./reports-BpI_HO2o.mjs");
gsapWithCSS.registerPlugin(ScrollTrigger);
const Route$1 = createFileRoute("/reports")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component"),
  head: () => ({
    meta: [{
      title: "Reports — Electrosoft Automation RLTS"
    }, {
      name: "description",
      content: "View, inspect and export reactor test reports."
    }]
  })
});
const $$splitComponentImporter = () => import("./index-Bqj-4uzM.mjs");
const Route = createFileRoute("/")({
  component: lazyRouteComponent($$splitComponentImporter, "component"),
  head: () => ({
    meta: [{
      title: "Testing — Electrosoft Automation RLTS"
    }, {
      name: "description",
      content: "Real-time reactor excitation rise and exponential decay monitoring."
    }]
  })
});
const SetupRoute = Route$3.update({
  id: "/setup",
  path: "/setup",
  getParentRoute: () => Route$4
});
const SettingsRoute = Route$2.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => Route$4
});
const ReportsRoute = Route$1.update({
  id: "/reports",
  path: "/reports",
  getParentRoute: () => Route$4
});
const IndexRoute = Route.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$4
});
const rootRouteChildren = {
  IndexRoute,
  ReportsRoute,
  SettingsRoute,
  SetupRoute
};
const routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  logo as l,
  router as r
};
