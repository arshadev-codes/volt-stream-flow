import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useTheme, B as BrandHeader } from "./settings-BuFBVS38.mjs";
import { u as useSettings } from "./useSettings-CguaxJl3.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { l as Settings, R as Radio, I as Info, D as Database, f as LockOpen, e as Lock } from "../_libs/lucide-react.mjs";
import "./router-KWJ3Ta83.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/gsap.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function SettingsPage() {
  const {
    theme,
    toggle
  } = useTheme();
  const {
    settings,
    update
  } = useSettings();
  const [multiplierUnlocked, setMultiplierUnlocked] = reactExports.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-4xl space-y-6 px-4 py-8 lg:px-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(BrandHeader, { theme, onToggleTheme: toggle }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 12
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.4
    }, className: "panel p-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.25em] text-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "h-4 w-4 text-amber-500" }),
        "System Settings"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Preferences are stored locally and apply to all future tests on this workstation." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 16
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.45,
      delay: 0.05
    }, className: "panel p-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 font-display text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Radio, { className: "h-4 w-4 text-amber-500" }),
        "Test Mode"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "group flex cursor-pointer items-start justify-between gap-6 rounded-md border border-border bg-card p-5 transition hover:border-amber-500/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-foreground", children: "Live Hardware Mode" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: "When enabled, the dashboard connects to the real test bench over SignalR and starts listening for live data immediately — the demo simulation panel is hidden. When disabled, the dashboard runs in demo mode with the simulation panel and no hardware connection is attempted." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 inline-flex items-center gap-1.5 rounded-sm border border-border bg-background px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-3 w-3" }),
            "Current: ",
            settings.dataSource === "live" ? "Live Hardware" : "Demo Simulation"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: settings.dataSource === "live", onChange: (v) => update({
          dataSource: v ? "live" : "demo"
        }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 16
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.45,
      delay: 0.08
    }, className: "panel p-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 font-display text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "h-4 w-4 text-amber-500" }),
        "Data Acquisition"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "group flex cursor-pointer items-start justify-between gap-6 rounded-md border border-border bg-card p-5 transition hover:border-amber-500/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-foreground", children: "Store Raw Data" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: "When enabled, the full 0.25 ms raw acquisition stream is persisted to the database alongside the 1 ms analysis dataset. When disabled, only the analysis dataset is stored — significantly reducing storage footprint." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 inline-flex items-center gap-1.5 rounded-sm border border-border bg-background px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-3 w-3" }),
            "Current: ",
            settings.storeRawData ? "Raw + Analysis" : "Analysis only"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: settings.storeRawData, onChange: (v) => update({
          storeRawData: v
        }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 16
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.45,
      delay: 0.1
    }, className: "panel p-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2 font-display text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "h-4 w-4 text-amber-500" }),
        "Test Calculation Constants"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md border border-border bg-card p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-foreground", children: "Current Multiplier" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-muted-foreground", children: "Used in Idc for Linearity Test = Rated AC RMS Current × multiplier × √2. Locked at the standard value (1.5) by default — unlock only if the test procedure explicitly calls for a different multiplier." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setMultiplierUnlocked((v) => !v), className: `inline-flex shrink-0 items-center gap-1.5 rounded-md border px-3 py-1.5 font-mono text-[11px] font-bold uppercase tracking-wider transition ${multiplierUnlocked ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-border bg-background text-muted-foreground hover:border-amber-500/40"}`, children: [
            multiplierUnlocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(LockOpen, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-3.5 w-3.5" }),
            multiplierUnlocked ? "Unlocked" : "Locked"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", step: "0.01", disabled: !multiplierUnlocked, value: settings.currentMultiplier, onChange: (e) => update({
          currentMultiplier: parseFloat(e.target.value) || 1.5
        }), className: "mt-4 w-40 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50" }),
        settings.currentMultiplier !== 1.5 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 inline-flex items-center gap-1.5 rounded-sm border border-amber-500/40 bg-amber-500/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber-500", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-3 w-3" }),
          "Non-standard value in use: ",
          settings.currentMultiplier
        ] })
      ] })
    ] })
  ] }) });
}
function Toggle({
  checked,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => onChange(!checked), className: `relative mt-1 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition ${checked ? "bg-amber-500" : "bg-secondary"}`, "aria-pressed": checked, children: /* @__PURE__ */ jsxRuntimeExports.jsx(motion.span, { layout: true, transition: {
    type: "spring",
    stiffness: 500,
    damping: 32
  }, className: `inline-block h-5 w-5 transform rounded-full bg-background shadow ${checked ? "translate-x-5" : "translate-x-0.5"}` }) });
}
export {
  SettingsPage as component
};
