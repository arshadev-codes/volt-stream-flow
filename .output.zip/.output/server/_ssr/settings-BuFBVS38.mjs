import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { l as logo } from "./router-KWJ3Ta83.mjs";
import { h as Moon, o as Sun } from "../_libs/lucide-react.mjs";
function ThemeToggle({ theme, onToggle }) {
  const isDark = theme === "dark";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      onClick: onToggle,
      "aria-label": "Toggle color theme",
      className: "group relative inline-flex h-9 w-16 items-center rounded-full border border-border bg-secondary/60 px-1 transition-colors hover:border-accent-foreground/40",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: `flex h-7 w-7 items-center justify-center rounded-full bg-background shadow-md ring-1 ring-border transition-transform ${isDark ? "translate-x-7" : "translate-x-0"}`,
            children: isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "h-3.5 w-3.5 text-accent-foreground" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "h-3.5 w-3.5 text-amber-500" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: `pointer-events-none absolute left-2 h-3.5 w-3.5 text-amber-400/70 transition-opacity ${isDark ? "opacity-30" : "opacity-0"}` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: `pointer-events-none absolute right-2 h-3.5 w-3.5 text-sky-300/70 transition-opacity ${isDark ? "opacity-0" : "opacity-40"}` })
      ]
    }
  );
}
function BrandHeader({ theme, onToggleTheme }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "flex flex-wrap items-center justify-between gap-4 border-b border-border/70 pb-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative flex h-12 w-12 items-center justify-center rounded-md border border-border bg-card shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: logo,
          alt: "Electrosoft Automation",
          className: `h-9 w-9 object-contain ${theme === "dark" ? "invert" : ""}`
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.45em] text-amber-500 dark:text-amber-400", children: "Electrosoft Automation" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display mt-1 text-2xl font-bold tracking-tight text-foreground", children: "Reactor Linearity Testing System" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground", children: "Industrial excitation rise & exponential decay analyzer · PLC / Modbus / WebSocket ready" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeToggle, { theme, onToggle: onToggleTheme }) })
  ] });
}
const STORAGE_KEY = "esa-theme";
function getInitial() {
  if (typeof window === "undefined") return "dark";
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === "light" || stored === "dark") {
      return stored;
    }
  } catch {
  }
  return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
}
function useTheme() {
  const [theme, setTheme] = reactExports.useState(getInitial);
  reactExports.useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(theme);
    root.setAttribute("data-theme", theme);
    root.style.colorScheme = theme;
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
    }
  }, [theme]);
  const toggle = reactExports.useCallback(() => {
    setTheme(
      (current) => current === "dark" ? "light" : "dark"
    );
  }, []);
  return {
    theme,
    setTheme,
    toggle
  };
}
const KEY = "esa.settings.v1";
const DEFAULTS = {
  storeRawData: false,
  currentMultiplier: 1.5,
  dataSource: "live"
};
const listeners = /* @__PURE__ */ new Set();
function read() {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULTS;
    return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    return DEFAULTS;
  }
}
let cache = read();
function getSettings() {
  return cache;
}
function updateSettings(patch) {
  cache = { ...cache, ...patch };
  try {
    localStorage.setItem(KEY, JSON.stringify(cache));
  } catch {
  }
  listeners.forEach((l) => l(cache));
}
function subscribeSettings(l) {
  listeners.add(l);
  const onStorage = (e) => {
    if (e.key === KEY) {
      cache = read();
      l(cache);
    }
  };
  if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(l);
    if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
  };
}
export {
  BrandHeader as B,
  useTheme as a,
  getSettings as g,
  subscribeSettings as s,
  updateSettings as u
};
