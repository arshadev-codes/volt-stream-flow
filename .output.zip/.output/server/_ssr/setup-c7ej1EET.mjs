import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useTheme, B as BrandHeader } from "./settings-BuFBVS38.mjs";
import { u as useTestObjects, e as computeRatedPowerVA, f as computeRatedVoltageV, d as computeRatedAcRmsCurrent, g as computeResAt20DegC, P as PU_LINEARITY, c as computeIdcForLinearityTest } from "./reactorCalcs-BDTazTR4.mjs";
import { u as useSettings } from "./useSettings-CguaxJl3.mjs";
import { P as Pencil, j as Plus, X, B as Boxes, T as Trash2, e as Lock, b as CircleCheck, c as CircleX, a as Circle } from "../_libs/lucide-react.mjs";
import "./router-KWJ3Ta83.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/gsap.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
const EMPTY = {
  serialNumber: "",
  name: "",
  manufacturer: "",
  projectName: "",
  customerName: "",
  workOrder: "",
  frequency: 50,
  inductance: 0,
  notes: "",
  // Nameplate data (linearity report)
  ratedPowerValue: 0,
  ratedPowerUnit: "MVAR",
  ratedVoltageNameplate: 0,
  ratedVoltageUnit: "V",
  phases: 3,
  resAtRefTemp: 0,
  refTempForRes: 75,
  // NOTE: renamed from "resIncreaseByLeads" -> "resIncreaseByLeadsPu" so this
  // key matches what the JSX below actually reads/writes AND what
  // pdfReport.tsx / reactorCalcs.computeUltimateDcVoltage read on the
  // TestObject. Previously these were different names, so the value never
  // made it through and always showed "—" on the report.
  resIncreaseByLeadsPu: 0,
  resIncreaseByLeadsUnit: "%"
};
function SetupPage() {
  const {
    theme,
    toggle
  } = useTheme();
  const {
    objects,
    create,
    update: updateObject,
    remove
  } = useTestObjects();
  const {
    settings
  } = useSettings();
  const [form, setForm] = reactExports.useState(EMPTY);
  const [editingId, setEditingId] = reactExports.useState(null);
  const update = (k, v) => setForm((f) => ({
    ...f,
    [k]: v
  }));
  const objectToForm = (o) => ({
    serialNumber: o.serialNumber,
    name: o.name ?? "",
    manufacturer: o.manufacturer ?? "",
    projectName: o.projectName ?? "",
    customerName: o.customerName ?? "",
    workOrder: o.workOrder ?? "",
    frequency: o.frequency ?? 0,
    inductance: o.inductance ?? 0,
    notes: o.notes ?? "",
    ratedPowerValue: o.ratedPowerValue ?? 0,
    ratedPowerUnit: o.ratedPowerUnit ?? "MVAR",
    ratedVoltageNameplate: o.ratedVoltageNameplate ?? 0,
    ratedVoltageUnit: "V",
    phases: o.phases ?? 3,
    resAtRefTemp: o.resAtRefTemp ?? 0,
    refTempForRes: o.refTempForRes ?? 75,
    resIncreaseByLeadsPu: o.resIncreaseByLeadsPu ?? 0,
    resIncreaseByLeadsUnit: "%"
  });
  const startEdit = (o) => {
    setForm(objectToForm(o));
    setEditingId(o.id);
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  const cancelEdit = () => {
    setForm(EMPTY);
    setEditingId(null);
  };
  const ratedPowerVA = reactExports.useMemo(() => computeRatedPowerVA(Number(form.ratedPowerValue) || 0, form.ratedPowerUnit), [form.ratedPowerValue, form.ratedPowerUnit]);
  const ratedVoltageV = reactExports.useMemo(() => computeRatedVoltageV(Number(form.ratedVoltageNameplate) || 0, form.ratedVoltageUnit), [form.ratedVoltageNameplate, form.ratedVoltageUnit]);
  const ratedAcRmsCurrent = reactExports.useMemo(() => computeRatedAcRmsCurrent(ratedPowerVA, ratedVoltageV, form.phases), [ratedPowerVA, ratedVoltageV, form.phases]);
  const resAt20DegC = reactExports.useMemo(() => computeResAt20DegC(Number(form.resAtRefTemp) || 0, Number(form.refTempForRes) || 0), [form.resAtRefTemp, form.refTempForRes]);
  const currentMultiplier = settings.currentMultiplier || PU_LINEARITY;
  const idcForLinearityTest = reactExports.useMemo(() => computeIdcForLinearityTest(ratedAcRmsCurrent, currentMultiplier), [ratedAcRmsCurrent, currentMultiplier]);
  const [saving, setSaving] = reactExports.useState(false);
  const submit = async (e) => {
    e.preventDefault();
    if (!form.serialNumber.trim()) {
      alert("Serial number is required.");
      return;
    }
    const missing = [];
    if (!form.ratedPowerValue) missing.push("Rated Power");
    if (!form.ratedVoltageNameplate) missing.push("Rated Voltage");
    if (!form.frequency) missing.push("Frequency");
    if (!form.inductance) missing.push("Inductance");
    if (!form.resAtRefTemp) missing.push("Res/ph at Ref Temp");
    if (!form.refTempForRes && form.refTempForRes !== 0) missing.push("Ref Temp for Res");
    if (missing.length > 0) {
      alert(`Please fill in the following required fields before creating the object:

${missing.join("\n")}`);
      return;
    }
    setSaving(true);
    const payload = {
      serialNumber: form.serialNumber.trim(),
      name: form.name.trim(),
      manufacturer: form.manufacturer.trim() || void 0,
      projectName: form.projectName.trim(),
      customerName: form.customerName.trim(),
      workOrder: form.workOrder.trim(),
      // FIX: these three are required on TestObject but were never being
      // set here, so rated_voltage / rated_current always saved as 0.
      ratedVoltage: ratedVoltageV || 0,
      maxVoltage: ratedVoltageV || 0,
      ratedCurrent: ratedAcRmsCurrent || 0,
      frequency: Number(form.frequency) || void 0,
      inductance: Number(form.inductance) || void 0,
      notes: form.notes.trim() || void 0,
      ratedPowerValue: Number(form.ratedPowerValue) || void 0,
      ratedPowerUnit: form.ratedPowerUnit,
      ratedPowerVA: ratedPowerVA || void 0,
      ratedVoltageNameplate: ratedVoltageV || void 0,
      phases: Number(form.phases) || void 0,
      resAtRefTemp: Number(form.resAtRefTemp) || void 0,
      refTempForRes: Number(form.refTempForRes) || void 0,
      resIncreaseByLeadsPu: Number(form.resIncreaseByLeadsPu) || void 0,
      ratedAcRmsCurrent: ratedAcRmsCurrent || void 0,
      resAt20DegC: resAt20DegC || void 0,
      idcForLinearityTest: idcForLinearityTest || void 0
    };
    const result = editingId ? await updateObject(editingId, payload) : await create(payload);
    setSaving(false);
    if (!result.ok) {
      alert(result.error);
      return;
    }
    setForm(EMPTY);
    setEditingId(null);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl space-y-6 px-4 py-8 lg:px-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(BrandHeader, { theme, onToggleTheme: toggle }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 lg:grid-cols-[1fr_1.1fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "panel space-y-4 p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.2em]", children: [
            editingId ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4 text-amber-500" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 text-amber-500" }),
            editingId ? "Edit Test Object" : "Create Test Object"
          ] }),
          editingId && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: cancelEdit, className: "inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-muted-foreground hover:bg-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }),
            " Cancel"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Serial Number *", value: form.serialNumber, onChange: (v) => update("serialNumber", v), placeholder: "RX-001" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Description", value: form.name, onChange: (v) => update("name", v), placeholder: "Reactor Unit A" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Project Name", value: form.projectName, onChange: (v) => update("projectName", v), placeholder: "Substation Upgrade" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Customer Name", value: form.customerName, onChange: (v) => update("customerName", v), placeholder: "Acme Power Co." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Work Order", value: form.workOrder, onChange: (v) => update("workOrder", v), placeholder: "WO-2026-0421" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Frequency (Hz)", type: "number", value: form.frequency, onChange: (v) => update("frequency", Number(v)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Inductance (H)", type: "number", value: form.inductance, onChange: (v) => update("inductance", Number(v)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: "Rated Power" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: form.ratedPowerValue, onChange: (e) => update("ratedPowerValue", Number(e.target.value)), placeholder: "150", className: "w-full min-w-0 flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: form.ratedPowerUnit, onChange: (e) => update("ratedPowerUnit", e.target.value), className: "w-24 shrink-0 rounded-md border border-border bg-card px-2 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "VAR", children: "VAR" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "KVAR", children: "KVAR" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "MVAR", children: "MVAr" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: "Rated Voltage" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: form.ratedVoltageNameplate, onChange: (e) => update("ratedVoltageNameplate", Number(e.target.value)), placeholder: "420000", className: "w-full min-w-0 flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: form.ratedVoltageUnit, onChange: (e) => update("ratedVoltageUnit", e.target.value), className: "w-20 shrink-0 rounded-md border border-border bg-card px-2 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "V", children: "V" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "kV", children: "kV" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "MV", children: "MV" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: "No. of Phases" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: form.phases, onChange: (e) => update("phases", Number(e.target.value)), className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: 1, children: "1 (Single Phase)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: 3, children: "3 (Three Phase)" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Res/ph at Ref Temp (Ω)", type: "number", value: form.resAtRefTemp, onChange: (v) => update("resAtRefTemp", Number(v)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Ref Temp for Res (°C)", type: "number", value: form.refTempForRes, onChange: (v) => update("refTempForRes", Number(v)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: "Res Increase by Leads" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: form.resIncreaseByLeadsPu, onChange: (e) => update("resIncreaseByLeadsPu", Number(e.target.value)), placeholder: "e.g. 1.1", className: "w-full min-w-0 flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: form.resIncreaseByLeadsUnit, onChange: (e) => update("resIncreaseByLeadsUnit", e.target.value), className: "w-20 shrink-0 rounded-md border border-border bg-card px-2 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Ω", children: "Ω" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "%", children: "%" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(LockedField, { label: "Rated AC RMS Current, A", value: ratedAcRmsCurrent }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(LockedField, { label: "Res/ph @ 20°C, Ω", value: resAt20DegC }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(LockedField, { label: "Idc for Linearity Test, A", value: idcForLinearityTest })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: "Notes" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { value: form.notes, onChange: (e) => update("notes", e.target.value), rows: 3, className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring", placeholder: "Optional" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", disabled: saving, className: "w-full rounded-md bg-amber-500 px-4 py-2.5 text-xs font-bold uppercase tracking-widest text-background hover:brightness-110 disabled:opacity-60", children: saving ? "Saving..." : editingId ? "Update Object" : "Create Object" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "panel p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.2em]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Boxes, { className: "h-4 w-4 text-amber-500" }),
            "All Test Objects"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-sm border border-border bg-card px-2 py-0.5 font-mono text-[11px] text-muted-foreground", children: objects.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          objects.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border border-dashed border-border p-6 text-center text-sm text-muted-foreground", children: "No test objects yet. Create one to get started." }),
          objects.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3 rounded-md border border-border bg-card p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status: o.status }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-semibold text-foreground", children: o.serialNumber }),
                o.name && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate text-sm text-muted-foreground", children: [
                  "· ",
                  o.name
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 font-mono text-[11px] text-muted-foreground", children: [
                o.workOrder ? `WO ${o.workOrder}` : "",
                o.customerName ? ` · ${o.customerName}` : ""
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => startEdit(o), className: "inline-flex h-8 w-8 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-accent hover:text-foreground", "aria-label": "Edit", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => confirm(`Delete ${o.serialNumber}? Its report will also be deleted.`) && remove(o.id), className: "inline-flex h-8 w-8 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-destructive hover:text-destructive-foreground", "aria-label": "Delete", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" }) })
            ] })
          ] }, o.id))
        ] })
      ] })
    ] })
  ] }) });
}
function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type, value, onChange: (e) => onChange(e.target.value), placeholder, className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-ring" })
  ] });
}
function LockedField({
  label,
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "block", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mb-1 flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.25em] text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-2.5 w-2.5" }),
      " ",
      label
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full cursor-not-allowed select-none rounded-md border border-dashed border-border bg-card/60 px-3 py-2 font-mono text-sm text-foreground/80 opacity-90", children: value ? value.toFixed(4) : "—" })
  ] });
}
function StatusIcon({
  status
}) {
  if (status === "passed") return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4 text-[var(--ok)]" });
  if (status === "failed") return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-4 w-4 text-destructive" });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { className: "h-4 w-4 text-muted-foreground" });
}
export {
  SetupPage as component
};
