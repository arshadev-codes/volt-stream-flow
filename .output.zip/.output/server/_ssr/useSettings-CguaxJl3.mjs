import { r as reactExports } from "../_libs/react.mjs";
import { g as getSettings, s as subscribeSettings, u as updateSettings } from "./settings-BuFBVS38.mjs";
function useSettings() {
  const [settings, setSettings] = reactExports.useState(getSettings());
  reactExports.useEffect(() => subscribeSettings(setSettings), []);
  return { settings, update: updateSettings };
}
export {
  useSettings as u
};
