globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { a as HTTPError, d as defineHandler, t as toEventHandler, b as defineLazyEventHandler, H as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/apple-touch-icon.png": {
    "type": "image/png",
    "etag": '"1aff-JyvJQWId1btWpSKA2Y7ka7ajvgs"',
    "mtime": "2026-06-01T09:08:09.596Z",
    "size": 6911,
    "path": "../public/apple-touch-icon.png"
  },
  "/favicon-96x96.png": {
    "type": "image/png",
    "etag": '"1159-Xg/378CpK4Dqig4smAiNurH3/iU"',
    "mtime": "2026-06-01T09:08:09.600Z",
    "size": 4441,
    "path": "../public/favicon-96x96.png"
  },
  "/electrosoft-logo.png": {
    "type": "image/png",
    "etag": '"b293-gRXQXHjSN/eOg4Bqi6I2ImECdy4"',
    "mtime": "2026-06-01T09:08:09.599Z",
    "size": 45715,
    "path": "../public/electrosoft-logo.png"
  },
  "/logo-black.jpg": {
    "type": "image/jpeg",
    "etag": '"2183-+IDvrOdnO0BgkWWzpZytKz/s8/k"',
    "mtime": "2026-08-11T10:15:35.959Z",
    "size": 8579,
    "path": "../public/logo-black.jpg"
  },
  "/registerSW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"86-uD38uo0sV8qINzJL85XzR0gDOlA"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 134,
    "path": "../public/registerSW.js"
  },
  "/logo-black.png": {
    "type": "image/png",
    "etag": '"3626-EcuHXwmGMHdXMuWoZB5mbdAKLqg"',
    "mtime": "2026-08-11T10:14:25.384Z",
    "size": 13862,
    "path": "../public/logo-black.png"
  },
  "/assets/lock-C3QIv79C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca-e3Nb5avKGr+Y4XFm1yXfwO/DI0E"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 202,
    "path": "../public/assets/lock-C3QIv79C.js"
  },
  "/favicon.svg": {
    "type": "image/svg+xml",
    "etag": '"f1e1-vqxWou8SCDNV/bNrT6zF6fa0Kr4"',
    "mtime": "2026-06-01T09:08:09.602Z",
    "size": 61921,
    "path": "../public/favicon.svg"
  },
  "/web-app-manifest-192.png": {
    "type": "image/png",
    "etag": '"1d42-2kCruLN/MqwBYejQtW0JPkBTqiQ"',
    "mtime": "2026-06-01T09:08:09.604Z",
    "size": 7490,
    "path": "../public/web-app-manifest-192.png"
  },
  "/assets/electrosoft-logo-BtOsNG6c.png": {
    "type": "image/png",
    "etag": '"b293-gRXQXHjSN/eOg4Bqi6I2ImECdy4"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 45715,
    "path": "../public/assets/electrosoft-logo-BtOsNG6c.png"
  },
  "/assets/index-UebqjXeu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"20833-wQZ1SYeLY9QrdBG9Zs778wbn3Ps"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 133171,
    "path": "../public/assets/index-UebqjXeu.js"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": '"b2-MPfSp2xhfsbkyg4ugFlgq/L0C6E"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 178,
    "path": "../public/manifest.webmanifest"
  },
  "/assets/radio-BfEZ7WJE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"177-nHqjhZr0WcwgDGLPA8N5BqNg1l0"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 375,
    "path": "../public/assets/radio-BfEZ7WJE.js"
  },
  "/assets/proxy-CC5X1ErV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1dc90-dt//vifJTRJXktFh1POMQuz8zTI"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 122e3,
    "path": "../public/assets/proxy-CC5X1ErV.js"
  },
  "/assets/settings-Be64rMmn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"eaa-iV2k/xa9sZCRjHEnniyyjcot7WY"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 3754,
    "path": "../public/assets/settings-Be64rMmn.js"
  },
  "/assets/index-CCIoDcbZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"73a52-PDjUc1uLRQE28C/cGSlaDHq12XI"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 473682,
    "path": "../public/assets/index-CCIoDcbZ.js"
  },
  "/assets/settings-CRy35C5F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1a63-X/bUGu+Go4ZuPbPr2/6MCv2o5VM"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 6755,
    "path": "../public/assets/settings-CRy35C5F.js"
  },
  "/assets/reactorCalcs-voXb2-6L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"38e28-TJBQOlKreRJatIUlpwA80VbyP+0"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 233e3,
    "path": "../public/assets/reactorCalcs-voXb2-6L.js"
  },
  "/assets/setup-CCF47u2I.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"32a6-QWvcWBxv8eDlbEUf479BwPRBJ4c"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 12966,
    "path": "../public/assets/setup-CCF47u2I.js"
  },
  "/assets/useSettings-C97beZ3M.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"cf-Jh/3rXgbN81Xyl3JV1FDNaK2ZCs"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 207,
    "path": "../public/assets/useSettings-C97beZ3M.js"
  },
  "/web-app-manifest-512.png": {
    "type": "image/png",
    "etag": '"730c-hvWqSe0N8ioChmZ4+7ftkq6Xmdk"',
    "mtime": "2026-06-01T09:08:09.604Z",
    "size": 29452,
    "path": "../public/web-app-manifest-512.png"
  },
  "/assets/styles-CBO9e5Cy.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1518f-fpI6B8/PuIwI1dY/PUVihPAlHsI"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 86415,
    "path": "../public/assets/styles-CBO9e5Cy.css"
  },
  "/assets/VoltageCurrentGraph-Dt1jgdOV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5e094-PzJk9wGPZRzU65taPI/hOhnVGMQ"',
    "mtime": "2026-09-17T06:22:26.416Z",
    "size": 385172,
    "path": "../public/assets/VoltageCurrentGraph-Dt1jgdOV.js"
  },
  "/assets/reports-Be79kNhC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"175f95-VGbAWpBKESY249sqCmzcWd5fXWY"',
    "mtime": "2026-09-17T06:22:26.442Z",
    "size": 1531797,
    "path": "../public/assets/reports-Be79kNhC.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _MM37LD = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_rRkrU2 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_rRkrU2 };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_MM37LD)
].filter(Boolean);
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function createNitroApp() {
  const hooks = void 0;
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({
          error,
          context: errorCtx
        });
      }
    }
  };
  const h3App = createH3App({ onError(error, event) {
    return errorHandler(error, event);
  } });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  const app = {
    fetch: appHandler,
    h3: h3App,
    hooks,
    captureError
  };
  return app;
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  {
    h3App["~getMiddleware"] = (event, route) => {
      const pathname = event.url.pathname;
      const method = event.req.method;
      const middleware = [];
      {
        const routeRules = getRouteRules(method, pathname);
        event.context.routeRules = routeRules?.routeRules;
        if (routeRules?.routeRuleMiddleware.length) {
          middleware.push(...routeRules.routeRuleMiddleware);
        }
      }
      middleware.push(...h3App["~middleware"]);
      if (route?.data?.middleware?.length) {
        middleware.push(...route.data.middleware);
      }
      return middleware;
    };
  }
  return h3App;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
